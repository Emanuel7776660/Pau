from flask import Flask, render_template, request, session, redirect, flash, jsonify
from DataBase.conexion import conectar
from datetime import datetime
import random

app = Flask(__name__)
app.secret_key = "tamagotchi_secreto"

# =========================
# FUNCIONES AUXILIARES
# =========================

def obtener_mascota(id_usuario):
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT *
        FROM mascotas
        WHERE id_usuario=%s
        LIMIT 1
        """,
        (id_usuario,)
    )

    mascota = cursor.fetchone()

    cursor.close()
    conexion.close()

    return mascota


def cerrar(conexion, cursor):
    cursor.close()
    conexion.close()


def resetear_tiempo_mascota(id_mascota):
    """Reinicia el reloj de ultima_actualizacion para que no bajen puntos por inactividad."""
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        UPDATE mascotas
        SET ultima_actualizacion = NOW()
        WHERE id_mascota = %s
        """,
        (id_mascota,)
    )

    conexion.commit()
    cursor.close()
    conexion.close()


def actualizar_estado_mascota(id_mascota):
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT ultima_actualizacion
        FROM mascotas
        WHERE id_mascota=%s
        """,
        (id_mascota,)
    )

    fecha = cursor.fetchone()

    if fecha and fecha[0]:
        segundos = int((datetime.now() - fecha[0]).total_seconds())

        # Cada 10 segundos baja estado
        ciclos = segundos // 10

        if ciclos > 0:
            cursor.execute(
                """
                UPDATE mascotas
                SET
                hambre = GREATEST(hambre - (%s * 2), 0),
                energia = GREATEST(energia - (%s * 1), 0),
                felicidad = GREATEST(felicidad - (%s * 1), 0),
                salud = GREATEST(salud - (%s * 1), 0),
                ultima_actualizacion = NOW()
                WHERE id_mascota = %s
                """,
                (ciclos, ciclos, ciclos, ciclos, id_mascota)
            )
            conexion.commit()

    cursor.close()
    conexion.close()


@app.route("/estado_mascota")
def estado_mascota():
    if "id_usuario" not in session:
        return jsonify({"error": "no login"})

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if mascota:
        actualizar_estado_mascota(mascota[0])
        mascota = obtener_mascota(id_usuario)

        return jsonify({
            "hambre": mascota[4],
            "felicidad": mascota[5],
            "energia": mascota[6],
            "salud": mascota[7]
        })

    return jsonify({"error": "sin mascota"})

# =========================
# INICIO
# =========================

@app.route("/")
def inicio():
    return render_template("login.html")

# =========================
# LOGIN
# =========================

@app.route("/login", methods=["POST"])
def login():
    correo = request.form["correo"]
    password = request.form["password"]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT id_usuario, nombre
        FROM usuarios
        WHERE correo=%s
        AND password=%s
        """,
        (correo, password)
    )

    usuario = cursor.fetchone()
    cursor.close()
    conexion.close()

    if usuario:
        session["id_usuario"] = usuario[0]
        session["nombre"] = usuario[1]

        mascota = obtener_mascota(usuario[0])

        if mascota:
            # Sincronizar el reloj al iniciar sesión para evitar pérdida de puntos fuera de línea
            resetear_tiempo_mascota(mascota[0])
            return redirect("/juego")

        return render_template(
            "seleccion.html",
            nombre=usuario[1]
        )

    flash("Correo o contraseña incorrectos.", "error")
    return redirect("/")

# =========================
# REGISTRO
# =========================

@app.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        nombre = request.form["nombre"]
        edad = request.form["edad"]
        correo = request.form["correo"]
        password = request.form["password"]

        conexion = conectar()
        cursor = conexion.cursor(buffered=True)

        cursor.execute(
            """
            INSERT INTO usuarios (nombre, edad, correo, password)
            VALUES (%s, %s, %s, %s)
            """,
            (nombre, edad, correo, password)
        )

        conexion.commit()
        cursor.close()
        conexion.close()

        return redirect("/")

    return render_template("registro.html")

# =========================
# CREAR MASCOTA
# =========================

@app.route("/crear_mascota", methods=["POST"])
def crear_mascota():
    tipo = request.form["tipo"]
    nombre_mascota = request.form["nombre_mascota"]
    id_usuario = session["id_usuario"]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        INSERT INTO mascotas (id_usuario, tipo, nombre_mascota, ultima_actualizacion)
        VALUES (%s, %s, %s, NOW())
        """,
        (id_usuario, tipo, nombre_mascota)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    mascota = obtener_mascota(id_usuario)

    return render_template(
        "historia.html",
        mascota=mascota,
        tipo=tipo,
        nombre=nombre_mascota
    )

# =========================
# JUEGO PRINCIPAL
# =========================

@app.route("/juego")
def juego():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/elegir_mascota")

    actualizar_estado_mascota(mascota[0])
    mascota = obtener_mascota(id_usuario)

    hambre = mascota[4]
    felicidad = mascota[5]
    energia = mascota[6]
    salud = mascota[7]

    if hambre <= 20:
        mensaje = "😿 Tengo mucha hambre... ¿me das algo rico?"
    elif energia <= 20:
        mensaje = "😴 Estoy muy cansado, necesito dormir"
    elif felicidad <= 20:
        mensaje = "🥺 Estoy triste, juega conmigo"
    elif salud <= 20:
        mensaje = "🤒 No me siento muy bien"
    else:
        mensaje = "😊 Estoy muy feliz contigo, gracias por cuidarme"

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT nombre_objeto
        FROM inventario
        WHERE id_mascota=%s
        AND equipado=1
        """,
        (mascota[0],)
    )

    accesorios_db = cursor.fetchall()
    cursor.close()
    conexion.close()

    accesorios = [item[0] for item in accesorios_db]

    return render_template(
        "juego.html",
        mascota=mascota,
        mensaje=mensaje,
        accesorios=accesorios
    )

# =========================
# ALIMENTAR
# =========================

@app.route("/alimentar")
def alimentar():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if mascota:
        id_mascota = mascota[0]
        dinero = mascota[9]

        if dinero >= 10:
            conexion = conectar()
            cursor = conexion.cursor(buffered=True)

            cursor.execute(
                """
                UPDATE mascotas
                SET 
                hambre=LEAST(hambre+20,100),
                felicidad=LEAST(felicidad+5,100),
                dinero=dinero-10
                WHERE id_mascota=%s
                """,
                (id_mascota,)
            )

            cursor.execute(
                """
                INSERT INTO historial_acciones (id_mascota, accion)
                VALUES (%s, %s)
                """,
                (id_mascota, "Comió alimento (-10 monedas)")
            )

            conexion.commit()
            cursor.close()
            conexion.close()
        else:
            return """
            <h2>😿 Tu mascota no tiene suficiente dinero</h2>
            <a href="/juego">Volver</a>
            """
    return redirect("/juego")

# =========================
# DORMIR
# =========================

@app.route("/dormir")
def dormir():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if mascota:
        id_mascota = mascota[0]

        conexion = conectar()
        cursor = conexion.cursor(buffered=True)

        cursor.execute(
            """
            UPDATE mascotas
            SET energia=LEAST(energia+20,100),
                felicidad=LEAST(felicidad+5,100)
            WHERE id_mascota=%s
            """,
            (id_mascota,)
        )

        cursor.execute(
            """
            INSERT INTO historial_acciones (id_mascota, accion)
            VALUES (%s, %s)
            """,
            (id_mascota, "Durmió")
        )

        conexion.commit()
        cursor.close()
        conexion.close()

    return redirect("/juego")

# =========================
# MENU DE JUEGOS
# =========================

@app.route("/juegos")
def juegos():

    if "id_usuario" not in session:
        return redirect("/")

    mascota = obtener_mascota(session["id_usuario"])

    if not mascota:
        return redirect("/juego")

    # Energía muy baja
    if mascota[6] <= 15:

        return render_template(
            "sin_energia.html",
            mascota=mascota,
            mensaje="😴 Estoy muy cansado... antes de jugar necesito dormir."
        )

    return render_template(
        "juegos.html",
        mascota=mascota
    )
# =========================
# JUEGO DE PALABRAS
# =========================

preguntas = [
    ("Animal que dice miau", "gato"),
    ("Animal que dice guau", "perro"),
    ("Objeto para jugar", "juguete"),
    ("Comida de mascotas", "comida"),
    ("Animal que tiene rayas", "tigre"),
    ("Lugar donde duerme una mascota", "cama"),
    ("Animal que vuela y tiene plumas", "ave"),
    ("Animal conocido como el rey de la selva", "leon"),
    ("Animal que vive en el agua y nada", "pez"),
    ("Fruta amarilla que comen los monos", "platano"),
    ("Color del pasto", "verde"),
    ("Color del cielo en un día despejado", "azul"),
    ("Objeto que sirve para escribir", "lapiz"),
    ("Objeto donde guardamos libros", "estante"),
    ("Lugar donde estudian los niños", "escuela"),
    ("Persona que cuida animales", "veterinario"),
    ("Animal que tiene caparazón", "tortuga"),
    ("Animal que produce miel", "abeja"),
    ("Animal que salta y vive en charcos", "rana"),
    ("Animal que tiene una trompa larga", "elefante"),
    ("Animal que tiene ocho patas", "arana"),
    ("Parte del cuerpo que usamos para caminar", "pie"),
    ("Parte del cuerpo que usamos para ver", "ojo"),
    ("Objeto que usamos para dormir", "almohada"),
    ("Lugar donde compramos productos", "tienda"),
    ("Algo que usamos cuando llueve", "paraguas"),
    ("Objeto que usamos para jugar videojuegos", "control"),
    ("Comida italiana famosa con queso", "pizza"),
    ("Bebida que toman muchas personas por la mañana", "cafe"),
    ("Estrella que ilumina la Tierra", "sol")
]

@app.route("/juego_palabras", methods=["GET", "POST"])
def juego_palabras():
    if "id_usuario" not in session:
        return redirect("/")

    if request.method == "GET":
        pregunta = random.choice(preguntas)
        session["respuesta"] = pregunta[1]
        return render_template("palabras.html", pregunta=pregunta[0])

    respuesta = request.form["respuesta"].lower()

    if respuesta == session.get("respuesta"):
        conexion = conectar()
        cursor = conexion.cursor(buffered=True)

        cursor.execute(
            """
            SELECT id_mascota
            FROM mascotas
            WHERE id_usuario=%s
            LIMIT 1
            """,
            (session["id_usuario"],)
        )

        mascota = cursor.fetchone()

        if mascota:
            id_mascota = mascota[0]

            cursor.execute(
                """
                UPDATE mascotas
                SET
                experiencia = experiencia + 10,
                dinero = dinero + 15,
                felicidad = LEAST(felicidad + 10, 100)
                WHERE id_mascota=%s
                """,
                (id_mascota,)
            )

            cursor.execute(
                """
                INSERT INTO historial_acciones (id_mascota, accion)
                VALUES (%s, %s)
                """,
                (id_mascota, "Ganó 15 monedas jugando palabras")
            )

            conexion.commit()

        cursor.close()
        conexion.close()

        mensaje = """
🎉 ¡Excelente!
🐾 Tu mascota está muy feliz

Ganaste:
⭐ +10 experiencia
💰 +15 monedas
❤️ +10 felicidad
"""
        resultado = "correcto"
    else:
        mensaje = """
😿 Casi lo lograste
🐾 Tu mascota sigue confiando en ti

Intenta nuevamente,
seguro podrás conseguirlo ⭐
"""
        resultado = "incorrecto"

    return render_template("resultado.html", mensaje=mensaje, resultado=resultado)

# =========================
# TIENDA
# =========================

@app.route("/tienda")
def tienda():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT *
        FROM tienda
        ORDER BY categoria, nombre
        """
    )
    productos = cursor.fetchall()

    cursor.execute(
        """
        SELECT nombre_objeto
        FROM inventario
        WHERE id_mascota=%s
        """,
        (mascota[0],)
    )
    objetos = cursor.fetchall()

    accesorios_comprados = [objeto[0] for objeto in objetos]

    cursor.close()
    conexion.close()

    mensajes = [
        "🐾 ¡Vamos a comprar algo divertido!",
        "✨ Espero encontrar algo rico",
        "🎁 Me gustan los regalos",
        "💚 Gracias por cuidarme",
        "🛒 ¿Qué compraremos hoy?"
    ]

    return render_template(
        "tienda.html",
        mascota=mascota,
        productos=productos,
        accesorios_comprados=accesorios_comprados,
        mensaje=random.choice(mensajes)
    )


@app.route("/comprar/<int:id_producto>", methods=["POST"])
def comprar(id_producto):
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    id_mascota = mascota[0]
    dinero = mascota[8]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT nombre, precio, permanente
        FROM tienda
        WHERE id_producto=%s
        """,
        (id_producto,)
    )

    producto = cursor.fetchone()

    if not producto:
        cursor.close()
        conexion.close()
        flash("❌ Producto no encontrado.", "error")
        return redirect("/tienda")

    nombre, precio, permanente = producto[0], producto[1], producto[2]

    if dinero < precio:
        cursor.close()
        conexion.close()
        flash("💰 No tienes suficientes monedas para comprar este artículo.", "error")
        return redirect("/tienda")

    if permanente == 1:
        cursor.execute(
            """
            SELECT id_item
            FROM inventario
            WHERE id_mascota=%s AND nombre_objeto=%s
            """,
            (id_mascota, nombre)
        )
        if cursor.fetchone():
            cursor.close()
            conexion.close()
            flash(f"✨ {nombre} ya forma parte de tu colección.", "info")
            return redirect("/tienda")

    cursor.execute(
        """
        UPDATE mascotas
        SET dinero=dinero-%s
        WHERE id_mascota=%s
        """,
        (precio, id_mascota)
    )

    cursor.execute(
        """
        SELECT cantidad
        FROM inventario
        WHERE id_mascota=%s AND nombre_objeto=%s
        """,
        (id_mascota, nombre)
    )
    objeto = cursor.fetchone()

    if objeto and permanente == 0:
        cursor.execute(
            """
            UPDATE inventario
            SET cantidad=cantidad+1
            WHERE id_mascota=%s AND nombre_objeto=%s
            """,
            (id_mascota, nombre)
        )
    else:
        cursor.execute(
            """
            INSERT INTO inventario (id_mascota, nombre_objeto, cantidad, permanente, equipado)
            VALUES (%s, %s, 1, %s, 0)
            """,
            (id_mascota, nombre, permanente)
        )

    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, "Compró " + nombre)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    flash(f"🛍️ ¡Compraste {nombre}! Tu mascota está muy feliz. 🐾", "success")
    return redirect("/tienda")

# =========================
# EQUIPAR ACCESORIO
# =========================

@app.route("/equipar/<nombre>")
def equipar(nombre):
    if "id_usuario" not in session:
        return redirect("/")

    mascota = obtener_mascota(session["id_usuario"])

    if not mascota:
        return redirect("/juego")

    id_mascota = mascota[0]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT id_item
        FROM inventario
        WHERE id_mascota=%s AND nombre_objeto=%s AND permanente=1
        """,
        (id_mascota, nombre)
    )

    if not cursor.fetchone():
        cursor.close()
        conexion.close()
        flash("❌ No tienes ese accesorio.", "error")
        return redirect("/inventario")

    cursor.execute(
        """
        UPDATE inventario
        SET equipado=1
        WHERE id_mascota=%s AND nombre_objeto=%s
        """,
        (id_mascota, nombre)
    )

    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, "Equipó " + nombre)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    flash(f"✨ {nombre} equipado correctamente.", "success")
    return redirect("/inventario")

# =========================
# DESEQUIPAR ACCESORIO
# =========================

@app.route("/desequipar/<nombre>")
def desequipar(nombre):
    if "id_usuario" not in session:
        return redirect("/")

    mascota = obtener_mascota(session["id_usuario"])

    if not mascota:
        return redirect("/juego")

    id_mascota = mascota[0]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        UPDATE inventario
        SET equipado=0
        WHERE id_mascota=%s AND nombre_objeto=%s AND permanente=1
        """,
        (id_mascota, nombre)
    )

    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, "Desequipó " + nombre)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    flash(f"🎒 {nombre} fue guardado en el inventario.", "info")
    return redirect("/inventario")

# =========================
# AVENTURA TAMAGOTCHI
# =========================

@app.route("/aventura")
def aventura():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    eventos = [
        "🌲 Caminaste por un bosque misterioso",
        "🐾 Encontraste huellas extrañas",
        "💎 Viste algo brillante entre los árboles",
        "🌈 Llegaste a un lugar mágico",
        "⚔️ Apareció un pequeño desafío",
        "🦋 Tu mascota encontró un camino secreto"
    ]

    return render_template(
        "aventura.html",
        mascota=mascota,
        evento=random.choice(eventos)
    )


@app.route("/accion_aventura/<accion>")
def accion_aventura(accion):
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if mascota is None:
        return redirect("/juego")

    id_mascota = mascota[0]

    experiencia, dinero, felicidad, energia, hambre = 0, 0, 0, 0, 0
    texto = ""

    if accion == "explorar":
        experiencia, dinero, felicidad, energia, hambre = 10, 5, 5, -10, -5
        texto = "🌲 Exploró el bosque y encontró monedas"
    elif accion == "reto":
        experiencia, dinero, felicidad, energia, hambre = 20, 15, 3, -15, -10
        texto = "⚔️ Superó un reto y ganó una recompensa"
    elif accion == "tesoro":
        experiencia, dinero, felicidad, energia, hambre = 15, 30, 10, -5, 0
        texto = "💎 Encontró un tesoro escondido"
    elif accion == "descansar":
        felicidad, energia = 5, 20
        texto = "💤 Descansó y recuperó energía"

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        UPDATE mascotas
        SET
        experiencia = experiencia + %s,
        dinero = dinero + %s,
        felicidad = LEAST(GREATEST(felicidad + %s, 0), 100),
        energia = LEAST(GREATEST(energia + %s, 0), 100),
        hambre = LEAST(GREATEST(hambre + %s, 0), 100)
        WHERE id_mascota = %s
        """,
        (experiencia, dinero, felicidad, energia, hambre, id_mascota)
    )

    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, texto)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    return redirect("/aventura")

# =========================
# INVENTARIO
# =========================

@app.route("/inventario")
def inventario():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT nombre_objeto, cantidad, permanente, equipado
        FROM inventario
        WHERE id_mascota=%s
        ORDER BY nombre_objeto
        """,
        (mascota[0],)
    )

    objetos = cursor.fetchall()
    cursor.close()
    conexion.close()

    return render_template(
        "inventario.html",
        mascota=mascota,
        objetos=objetos
    )

# =========================
# USAR OBJETO INVENTARIO
# =========================

@app.route("/usar/<nombre>", methods=["POST"])
def usar(nombre):
    if "id_usuario" not in session:
        return {"mensaje": "❌ Sesión no iniciada"}

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return {"mensaje": "❌ No existe mascota"}

    id_mascota = mascota[0]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT cantidad, permanente
        FROM inventario
        WHERE id_mascota=%s AND nombre_objeto=%s
        """,
        (id_mascota, nombre)
    )

    objeto = cursor.fetchone()

    if not objeto:
        cursor.close()
        conexion.close()
        return {"mensaje": "❌ Objeto no encontrado"}

    cantidad, permanente = objeto[0], objeto[1]

    if permanente == 1:
        cursor.close()
        conexion.close()
        return {"mensaje": "✨ Este accesorio no se consume. Equípalo desde tu inventario 🎩"}

    mensajes = {
        "Croquetas": "🍪 ¡Delicioso! Mi pancita está feliz 🐾",
        "Carne": "🥩 ¡Qué rica comida! Estoy muy contento ❤️",
        "Pescado": "🐟 ¡Me encanta el pescado! Gracias 💚",
        "Lechuga": "🥬 ¡Comida saludable! Me siento mejor 🌱",
        "Pelota": "⚽ ¡Vamos a jugar! Me divertí mucho ⭐",
        "Hueso": "🦴 ¡Mi premio favorito! 🐶",
        "Ratón de Juguete": "🐭 ¡Qué divertido jugar contigo!",
        "Medicina": "💊 Me siento mucho mejor ❤️",
        "Vitamina": "🧪 Tengo mucha energía ⚡"
    }

    efectos = {
        "Croquetas": "hambre=LEAST(hambre+20,100)",
        "Carne": "hambre=LEAST(hambre+30,100), felicidad=LEAST(felicidad+10,100)",
        "Pescado": "hambre=LEAST(hambre+20,100)",
        "Lechuga": "hambre=LEAST(hambre+15,100), salud=LEAST(salud+10,100)",
        "Pelota": "felicidad=LEAST(felicidad+20,100)",
        "Hueso": "felicidad=LEAST(felicidad+15,100)",
        "Ratón de Juguete": "felicidad=LEAST(felicidad+20,100)",
        "Medicina": "salud=LEAST(salud+30,100)",
        "Vitamina": "energia=LEAST(energia+20,100)"
    }

    if nombre in efectos:
        cursor.execute(
            f"""
            UPDATE mascotas
            SET {efectos[nombre]}
            WHERE id_mascota=%s
            """,
            (id_mascota,)
        )

    if cantidad > 1:
        cursor.execute(
            """
            UPDATE inventario
            SET cantidad=cantidad-1
            WHERE id_mascota=%s AND nombre_objeto=%s
            """,
            (id_mascota, nombre)
        )
    else:
        cursor.execute(
            """
            DELETE FROM inventario
            WHERE id_mascota=%s AND nombre_objeto=%s
            """,
            (id_mascota, nombre)
        )

    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, "Usó " + nombre)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    return {"mensaje": mensajes.get(nombre, "🐾 Me gustó mucho")}

# =========================
# ACTUALIZAR ESTADO
# =========================

@app.route("/actualizar_estado")
def actualizar_estado():
    if "id_usuario" not in session:
        return redirect("/")

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        UPDATE mascotas
        SET hambre=GREATEST(hambre-5,0),
            energia=GREATEST(energia-5,0),
            felicidad=GREATEST(felicidad-3,0)
        WHERE id_usuario=%s
        """,
        (session["id_usuario"],)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    return redirect("/juego")

# =========================
# CERRAR SESIÓN
# =========================

@app.route("/logout", methods=["POST", "GET"])
def logout():
    if "id_usuario" in session:
        mascota = obtener_mascota(session["id_usuario"])
        if mascota:
            # Fijar el tiempo final antes de destruir la sesión
            resetear_tiempo_mascota(mascota[0])

    session.clear()
    return redirect("/")

# =========================
# VETERINARIO
# =========================

@app.route("/veterinario")
def veterinario():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    actualizar_estado_mascota(mascota[0])
    mascota = obtener_mascota(id_usuario)

    # Obtenemos productos de salud de la tienda (Medicinas / Vitaminas)
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT *
        FROM tienda
        WHERE categoria = 'Salud' OR nombre IN ('Medicina', 'Vitamina')
        """
    )
    productos_salud = cursor.fetchall()

    # Obtenemos los alimentos disponibles en el inventario de la mascota para sugerencias
    cursor.execute(
        """
        SELECT nombre_objeto, cantidad
        FROM inventario
        WHERE id_mascota=%s AND cantidad > 0
        """,
        (mascota[0],)
    )
    inventario = cursor.fetchall()

    cursor.close()
    conexion.close()

    # Generar sugerencia del veterinario basada en el inventario
    alimentos = [item[0] for item in inventario if item[0] in ['Croquetas', 'Carne', 'Pescado', 'Lechuga']]
    if alimentos:
        sugerencia_comida = f"Veo que tienes {alimentos[0]} en tu inventario, ¡eso le ayudará a recuperar fuerzas!"
    else:
        sugerencia_comida = "No tienes mucha comida saludable en tu inventario. ¡Consigue un poco de Lechuga o Pescado en la tienda!"

    # Mensaje según el estado de salud
    salud_mascota = mascota[7] # Índice del campo salud
    if salud_mascota == 0:
        mensaje_estado = "😿 No me siento nada bien, creo que veo la luz... :C"
    elif salud_mascota <= 30:
        mensaje_estado = "🤒 Me siento un poco débil y enfermo..."
    else:
        mensaje_estado = "😊 ¡Me siento bastante saludable, pero un chequeo nunca cae mal!"

    return render_template(
        "veterinario.html",
        mascota=mascota,
        productos_salud=productos_salud,
        sugerencia_comida=sugerencia_comida,
        mensaje_estado=mensaje_estado
    )


@app.route("/curar_veterinario")
def curar_veterinario():
    """Juego o chequeo médico rápido para mejorar la salud de la mascota"""
    if "id_usuario" not in session:
        return redirect("/")

    mascota = obtener_mascota(session["id_usuario"])
    if not mascota:
        return redirect("/juego")

    id_mascota = mascota[0]
    dinero = mascota[8] # Ajusta según el índice del dinero en tu tabla

    # El chequeo/tratamiento cuesta 10 monedas
    if dinero >= 10:
        conexion = conectar()
        cursor = conexion.cursor(buffered=True)

        cursor.execute(
            """
            UPDATE mascotas
            SET salud = LEAST(salud + 25, 100),
                felicidad = LEAST(felicidad + 10, 100),
                dinero = dinero - 10
            WHERE id_mascota = %s
            """,
            (id_mascota,)
        )

        cursor.execute(
            """
            INSERT INTO historial_acciones (id_mascota, accion)
            VALUES (%s, %s)
            """,
            (id_mascota, "Recibió atención veterinaria (-10 monedas)")
        )

        conexion.commit()
        cursor.close()
        conexion.close()

        flash("🩺 ¡El Dr. Peluditos atendió a tu mascota! Recupeó +25 de Salud y +10 de Felicidad.", "success")
    else:
        flash("💰 No tienes suficientes monedas para la consulta del veterinario (cuesta 10 monedas).", "error")

    return redirect("/veterinario")

# =========================
# JUEGO DE GATO (3 EN RAYA)
# =========================

@app.route("/juego_gato")
def juego_gato():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    # Validación de Energía (Restricción <= 15)
    if mascota[6] <= 15:
        return render_template("sin_energia.html", mascota=mascota)

    return render_template("gato.html", mascota=mascota)


@app.route("/ganar_gato", methods=["POST"])
def ganar_gato():
    """Otorga recompensa al ganar el juego de gato"""
    if "id_usuario" not in session:
        return jsonify({"error": "No autorizado"}), 401

    mascota = obtener_mascota(session["id_usuario"])
    if mascota:
        conexion = conectar()
        cursor = conexion.cursor(buffered=True)
        
        # Otorga +15 monedas y +10 felicidad
        cursor.execute("""
            UPDATE mascotas 
            SET dinero = dinero + 15,
                felicidad = LEAST(felicidad + 10, 100)
            WHERE id_mascota = %s
        """, (mascota[0],))
        
        conexion.commit()
        cursor.close()
        conexion.close()
        
        return jsonify({"mensaje": "¡Ganaste +15 monedas y +10 de felicidad!"})
    
    return jsonify({"error": "Mascota no encontrada"}), 404
# =========================
# EJECUTAR APP
# =========================

if __name__ == "__main__":
    app.run(debug=True)