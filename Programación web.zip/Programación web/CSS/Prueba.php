
<?php
echo "Hola soy un sushi de mango ";
echo "<br>";
echo  "Hoy es ".date ("d/m/y");


?>

