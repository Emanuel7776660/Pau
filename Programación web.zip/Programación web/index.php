<html>


<head>
<title> Esta es mi primer página web del cuatri </title>
<link rel="stylesheet" href="CSS/estilos.css">
</head>

<body>
<h1> Estoy emocionado por seguir aprendiendo lenguaje HTML. </h1>
<p> Parrafos normales alineados al centro. </p> <br> </br>
<p> A continuación una separación horizontal. </p>
<hr> </hr>
<b>Letras negritas</b>
<br> </br>
<i>Letras cursiva</i>
<br> </br>
<strike>texto tachado</strike>
<br> </br>
<big>texto Grande</big>
<br> </br>
<small>texto Pequeño</small>
<br> </br>

<sup> super indice </sup>  
<sub> sub indice </sub>

<hr>

<?php
include ´Prueba.php´;
?>


</body>
</html>