import mysql.connector


servidor = "localhost"
usuario = "root"
pas = ""
bd = "tamagotchi"
puerto = 3306

def conectar():

    
    conexion_error = None
    conexion = None

    try:
        conexion = mysql.connector.connect(
            host=servidor,
            user=usuario,
            password=pas,
            database=bd,
            port=puerto,
            charset="utf8mb4"
        )
    except Exception as e:
        conexion_error = str(e)
        print(f"❌ Error de conexión a la base de datos '{bd}': {conexion_error}")
        conexion = None

    return conexion


if __name__ == "__main__":
   
    con = conectar()
    if con and con.is_connected():
        print(" Conexión exitosa a MySQL (tamagotchi)")
        con.close()
    else:
        print(" No se pudo establecer la conexión.")