from flask import Flask, render_template, request, session, redirect, flash, jsonify
from DataBase.conexion import conectar
from datetime import datetime
import random

app = Flask(__name__)
app.secret_key = "tamagotchi_secreto"



def obtener_mascota(id_usuario):
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT *
        FROM mascotas
        WHERE id_usuario=%s
        LIMIT 1
        """,
        (id_usuario,)
    )

    mascota = cursor.fetchone()

    cursor.close()
    conexion.close()

    return mascota


def cerrar(conexion, cursor):
    cursor.close()
    conexion.close()


def resetear_tiempo_mascota(id_mascota):
    
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        UPDATE mascotas
        SET ultima_actualizacion = NOW()
        WHERE id_mascota = %s
        """,
        (id_mascota,)
    )

    conexion.commit()
    cursor.close()
    conexion.close()


def actualizar_estado_mascota(id_mascota):
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT ultima_actualizacion
        FROM mascotas
        WHERE id_mascota=%s
        """,
        (id_mascota,)
    )

    fecha = cursor.fetchone()

    if fecha and fecha[0]:
        segundos = int((datetime.now() - fecha[0]).total_seconds())

        # Cada 10 segundos baja estado
        ciclos = segundos // 10

        if ciclos > 0:
            cursor.execute(
                """
                UPDATE mascotas
                SET
                hambre = GREATEST(hambre - (%s * 2), 0),
                energia = GREATEST(energia - (%s * 1), 0),
                felicidad = GREATEST(felicidad - (%s * 1), 0),
                salud = GREATEST(salud - (%s * 1), 0),
                ultima_actualizacion = NOW()
                WHERE id_mascota = %s
                """,
                (ciclos, ciclos, ciclos, ciclos, id_mascota)
            )
            conexion.commit()

    cursor.close()
    conexion.close()


@app.route("/estado_mascota")
def estado_mascota():
    if "id_usuario" not in session:
        return jsonify({"error": "no login"})

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if mascota:
        actualizar_estado_mascota(mascota[0])
        mascota = obtener_mascota(id_usuario)

        return jsonify({
            "hambre": mascota[4],
            "felicidad": mascota[5],
            "energia": mascota[6],
            "salud": mascota[7]
        })

    return jsonify({"error": "sin mascota"})



@app.route("/")
def inicio():
    return render_template("login.html")



@app.route("/login", methods=["POST"])
def login():
    correo = request.form["correo"]
    password = request.form["password"]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT id_usuario, nombre
        FROM usuarios
        WHERE correo=%s
        AND password=%s
        """,
        (correo, password)
    )

    usuario = cursor.fetchone()
    cursor.close()
    conexion.close()

    if usuario:
        session["id_usuario"] = usuario[0]
        session["nombre"] = usuario[1]

        mascota = obtener_mascota(usuario[0])

        if mascota:
            
            resetear_tiempo_mascota(mascota[0])
            return redirect("/juego")

        return render_template(
            "seleccion.html",
            nombre=usuario[1]
        )

    flash("Correo o contraseña incorrectos.", "error")
    return redirect("/")


@app.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        nombre = request.form["nombre"]
        edad = request.form["edad"]
        correo = request.form["correo"]
        password = request.form["password"]

        conexion = conectar()
        cursor = conexion.cursor(buffered=True)

        cursor.execute(
            """
            INSERT INTO usuarios (nombre, edad, correo, password)
            VALUES (%s, %s, %s, %s)
            """,
            (nombre, edad, correo, password)
        )

        conexion.commit()
        cursor.close()
        conexion.close()

        return redirect("/")

    return render_template("registro.html")



@app.route("/crear_mascota", methods=["POST"])
def crear_mascota():
    tipo = request.form["tipo"]
    nombre_mascota = request.form["nombre_mascota"]
    id_usuario = session["id_usuario"]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        INSERT INTO mascotas (id_usuario, tipo, nombre_mascota, ultima_actualizacion)
        VALUES (%s, %s, %s, NOW())
        """,
        (id_usuario, tipo, nombre_mascota)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    mascota = obtener_mascota(id_usuario)

    return render_template(
        "historia.html",
        mascota=mascota,
        tipo=tipo,
        nombre=nombre_mascota
    )



@app.route("/juego")
def juego():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/elegir_mascota")

    actualizar_estado_mascota(mascota[0])
    mascota = obtener_mascota(id_usuario)

    hambre = mascota[4]
    felicidad = mascota[5]
    energia = mascota[6]
    salud = mascota[7]

    if hambre <= 20:
        mensaje = "😿 Tengo mucha hambre... ¿me das algo rico?"
    elif energia <= 20:
        mensaje = "😴 Estoy muy cansado, necesito dormir"
    elif felicidad <= 20:
        mensaje = "🥺 Estoy triste, juega conmigo"
    elif salud <= 20:
        mensaje = "🤒 No me siento muy bien"
    else:
        mensaje = "😊 Estoy muy feliz contigo, gracias por cuidarme"

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT nombre_objeto
        FROM inventario
        WHERE id_mascota=%s
        AND equipado=1
        """,
        (mascota[0],)
    )

    accesorios_db = cursor.fetchall()
    cursor.close()
    conexion.close()

    accesorios = [item[0] for item in accesorios_db]

    return render_template(
        "juego.html",
        mascota=mascota,
        mensaje=mensaje,
        accesorios=accesorios
    )


FRASES_LLENO = [
    "🤢 ¡Puf! Si me das un bocado más, voy a explotar.",
    "🚫 ¡Mi pancita dice que NO MÁS por hoy!",
    "🍔 ¡Ya no me cabe nada! Gracias, humano.",
    "😴 Me dio el 'mal del puerco'. ¡Déjame hacer la digestión!",
    "🛑 ¡Alerta! Mi barra de hambre va a explotar.",
    "🐧 ¡Auxilio! Ya ruedo de tan lleno que estoy."
]

@app.route("/usar_item", methods=["POST"])
def usar_item():
    if "id_usuario" not in session:
        return jsonify({"success": False, "error": "No autorizado"}), 401

    data = request.get_json() or request.form
    id_item = data.get("id_item")

    conexion = conectar()
    cursor = conexion.cursor(buffered=True, dictionary=True)

    # 1. Obtener la mascota del usuario
    cursor.execute(
        "SELECT id_mascota, hambre, felicidad, energia, salud FROM mascotas WHERE id_usuario=%s LIMIT 1",
        (session["id_usuario"],)
    )
    mascota = cursor.fetchone()

    if not mascota:
        cursor.close()
        conexion.close()
        return jsonify({"success": False, "error": "Mascota no encontrada"})

    # 2. VALIDACIÓN: Si el ítem es comida/consumible y ya está lleno
    if mascota["hambre"] >= 100:
        cursor.close()
        conexion.close()
        return jsonify({
            "success": False,
            "lleno": True,
            "mensaje": random.choice(FRASES_LLENO),
            "hambre": 100,
            "felicidad": mascota["felicidad"],
            "energia": mascota["energia"],
            "salud": mascota["salud"]
        })

    # 3. Si no está lleno, aplicamos el consumo (Ejemplo: aumenta +20 hambre)
    nueva_hambre = min(mascota["hambre"] + 20, 100)

    cursor.execute(
        "UPDATE mascotas SET hambre=%s WHERE id_mascota=%s",
        (nueva_hambre, mascota["id_mascota"])
    )
    
    # Restamos 1 al inventario del usuario
    cursor.execute(
        "UPDATE inventario SET cantidad = cantidad - 1 WHERE id_mascota=%s AND id_item=%s AND cantidad > 0",
        (mascota["id_mascota"], id_item)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    return jsonify({
        "success": True,
        "lleno": nueva_hambre >= 100,
        "hambre": nueva_hambre,
        "felicidad": mascota["felicidad"],
        "energia": mascota["energia"],
        "salud": mascota["salud"],
        "mensaje": "¡Mmm, qué delicioso!"
    })

@app.route("/dormir")
def dormir():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if mascota:
        id_mascota = mascota[0]

        conexion = conectar()
        cursor = conexion.cursor(buffered=True)

        cursor.execute(
            """
            UPDATE mascotas
            SET energia=LEAST(energia+20,100),
                felicidad=LEAST(felicidad+5,100)
            WHERE id_mascota=%s
            """,
            (id_mascota,)
        )

        cursor.execute(
            """
            INSERT INTO historial_acciones (id_mascota, accion)
            VALUES (%s, %s)
            """,
            (id_mascota, "Durmió")
        )

        conexion.commit()
        cursor.close()
        conexion.close()

    return redirect("/juego")


@app.route("/juegos")
def juegos():

    if "id_usuario" not in session:
        return redirect("/")

    mascota = obtener_mascota(session["id_usuario"])

    if not mascota:
        return redirect("/juego")

    # Energía muy baja
    if mascota[6] <= 15:

        return render_template(
            "sin_energia.html",
            mascota=mascota,
            mensaje="😴 Estoy muy cansado... antes de jugar necesito dormir."
        )

    return render_template(
        "juegos.html",
        mascota=mascota
    )

preguntas = [
    ("Animal que dice miau", "gato"),
    ("Animal que dice guau", "perro"),
    ("Objeto para jugar", "juguete"),
    ("Comida de mascotas", "comida"),
    ("Animal que tiene rayas", "tigre"),
    ("Lugar donde duerme una mascota", "cama"),
    ("Animal que vuela y tiene plumas", "ave"),
    ("Animal conocido como el rey de la selva", "leon"),
    ("Animal que vive en el agua y nada", "pez"),
    ("Fruta amarilla que comen los monos", "platano"),
    ("Color del pasto", "verde"),
    ("Color del cielo en un día despejado", "azul"),
    ("Objeto que sirve para escribir", "lapiz"),
    ("Objeto donde guardamos libros", "estante"),
    ("Lugar donde estudian los niños", "escuela"),
    ("Persona que cuida animales", "veterinario"),
    ("Animal que tiene caparazón", "tortuga"),
    ("Animal que produce miel", "abeja"),
    ("Animal que salta y vive en charcos", "rana"),
    ("Animal que tiene una trompa larga", "elefante"),
    ("Animal que tiene ocho patas", "arana"),
    ("Parte del cuerpo que usamos para caminar", "pie"),
    ("Parte del cuerpo que usamos para ver", "ojo"),
    ("Objeto que usamos para dormir", "almohada"),
    ("Lugar donde compramos productos", "tienda"),
    ("Algo que usamos cuando llueve", "paraguas"),
    ("Objeto que usamos para jugar videojuegos", "control"),
    ("Comida italiana famosa con queso", "pizza"),
    ("Bebida que toman muchas personas por la mañana", "cafe"),
    ("Estrella que ilumina la Tierra", "sol")
]

import random
from flask import redirect, render_template, request, session


@app.route("/juego_palabras", methods=["GET", "POST"])
def juego_palabras():
    if "id_usuario" not in session:
        return redirect("/")

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        "SELECT id_mascota, tipo FROM mascotas WHERE id_usuario=%s LIMIT 1",
        (session["id_usuario"],),
    )
    mascota_db = cursor.fetchone()

    id_mascota = None
    if mascota_db:
        id_mascota = mascota_db[0]
        session["tipo"] = mascota_db[1]

   
    if request.method == "GET":
        cursor.close()
        conexion.close()

        pregunta_elegida = random.choice(preguntas)

        session["pregunta_actual"] = pregunta_elegida[0]
        session["respuesta_correcta"] = str(pregunta_elegida[1]).lower().strip()

        return render_template("palabras.html", pregunta=pregunta_elegida[0])

   
    respuesta_usuario = request.form.get("respuesta", "").lower().strip()
    respuesta_esperada = session.get("respuesta_correcta", "").lower().strip()

  
    if not respuesta_esperada or not respuesta_usuario:
        cursor.close()
        conexion.close()
        return render_template("resultado.html", resultado="incorrecto")


    es_correcta = respuesta_usuario == respuesta_esperada


    session.pop("respuesta_correcta", None)

    if es_correcta:
      
        if id_mascota:
           
            cursor.execute(
                """
                UPDATE mascotas 
                SET experiencia = experiencia + 20, 
                    dinero = dinero + 15, 
                    felicidad = LEAST(felicidad + 10, 100) 
                WHERE id_mascota = %s
                """,
                (id_mascota,),
            )

            cursor.execute(
                """
                INSERT INTO historial_acciones (id_mascota, accion) 
                VALUES (%s, %s)
                """,
                (id_mascota, "Ganó 15 monedas en Juego de Palabras"),
            )


            conexion.commit()

        cursor.close()
        conexion.close()
        return render_template("resultado.html", resultado="correcto")

    else:
      
        cursor.close()
        conexion.close()
        return render_template("resultado.html", resultado="incorrecto")

    
@app.route("/tienda")
def tienda():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT *
        FROM tienda
        ORDER BY categoria, nombre
        """
    )
    productos = cursor.fetchall()

    cursor.execute(
        """
        SELECT nombre_objeto
        FROM inventario
        WHERE id_mascota=%s
        """,
        (mascota[0],)
    )
    objetos = cursor.fetchall()

    accesorios_comprados = [objeto[0] for objeto in objetos]

    cursor.close()
    conexion.close()

    mensajes = [
        "🐾 ¡Vamos a comprar algo divertido!",
        "✨ Espero encontrar algo rico",
        "🎁 Me gustan los regalos",
        "💚 Gracias por cuidarme",
        "🛒 ¿Qué compraremos hoy?"
    ]

    return render_template(
        "tienda.html",
        mascota=mascota,
        productos=productos,
        accesorios_comprados=accesorios_comprados,
        mensaje=random.choice(mensajes)
    )


@app.route("/comprar/<int:id_producto>", methods=["POST"])
def comprar(id_producto):
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    id_mascota = mascota[0]
    dinero = mascota[8]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT nombre, precio, permanente
        FROM tienda
        WHERE id_producto=%s
        """,
        (id_producto,)
    )

    producto = cursor.fetchone()

    if not producto:
        cursor.close()
        conexion.close()
        flash("❌ Producto no encontrado.", "error")
        return redirect("/tienda")

    nombre, precio, permanente = producto[0], producto[1], producto[2]

    if dinero < precio:
        cursor.close()
        conexion.close()
        flash("💰 No tienes suficientes monedas para comprar este artículo.", "error")
        return redirect("/tienda")

    if permanente == 1:
        cursor.execute(
            """
            SELECT id_item
            FROM inventario
            WHERE id_mascota=%s AND nombre_objeto=%s
            """,
            (id_mascota, nombre)
        )
        if cursor.fetchone():
            cursor.close()
            conexion.close()
            flash(f"✨ {nombre} ya forma parte de tu colección.", "info")
            return redirect("/tienda")

    cursor.execute(
        """
        UPDATE mascotas
        SET dinero=dinero-%s
        WHERE id_mascota=%s
        """,
        (precio, id_mascota)
    )

    cursor.execute(
        """
        SELECT cantidad
        FROM inventario
        WHERE id_mascota=%s AND nombre_objeto=%s
        """,
        (id_mascota, nombre)
    )
    objeto = cursor.fetchone()

    if objeto and permanente == 0:
        cursor.execute(
            """
            UPDATE inventario
            SET cantidad=cantidad+1
            WHERE id_mascota=%s AND nombre_objeto=%s
            """,
            (id_mascota, nombre)
        )
    else:
        cursor.execute(
            """
            INSERT INTO inventario (id_mascota, nombre_objeto, cantidad, permanente, equipado)
            VALUES (%s, %s, 1, %s, 0)
            """,
            (id_mascota, nombre, permanente)
        )

    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, "Compró " + nombre)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    flash(f"🛍️ ¡Compraste {nombre}! Tu mascota está muy feliz. 🐾", "success")
    return redirect("/tienda")



@app.route("/equipar/<nombre>")
def equipar(nombre):
    if "id_usuario" not in session:
        return redirect("/")

    mascota = obtener_mascota(session["id_usuario"])

    if not mascota:
        return redirect("/juego")

    id_mascota = mascota[0]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT id_item
        FROM inventario
        WHERE id_mascota=%s AND nombre_objeto=%s AND permanente=1
        """,
        (id_mascota, nombre)
    )

    if not cursor.fetchone():
        cursor.close()
        conexion.close()
        flash("❌ No tienes ese accesorio.", "error")
        return redirect("/inventario")

    cursor.execute(
        """
        UPDATE inventario
        SET equipado=1
        WHERE id_mascota=%s AND nombre_objeto=%s
        """,
        (id_mascota, nombre)
    )

    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, "Equipó " + nombre)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    flash(f"✨ {nombre} equipado correctamente.", "success")
    return redirect("/inventario")


@app.route("/desequipar/<nombre>")
def desequipar(nombre):
    if "id_usuario" not in session:
        return redirect("/")

    mascota = obtener_mascota(session["id_usuario"])

    if not mascota:
        return redirect("/juego")

    id_mascota = mascota[0]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        UPDATE inventario
        SET equipado=0
        WHERE id_mascota=%s AND nombre_objeto=%s AND permanente=1
        """,
        (id_mascota, nombre)
    )

    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, "Desequipó " + nombre)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    flash(f"🎒 {nombre} fue guardado en el inventario.", "info")
    return redirect("/inventario")

@app.route("/aventura")
def aventura():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    return render_template("aventura.html", mascota=mascota)


@app.route("/accion_aventura/guardar", methods=["POST"])
def guardar_aventura():
    if "id_usuario" not in session:
        return jsonify({"success": False, "error": "No autorizado"}), 401

    data = request.get_json()
    puntos = data.get("puntos", 0)
    comida_atrapada = data.get("comida", 0)

    experiencia = int(puntos * 1.5)
    dinero = int(puntos * 0.8)
    felicidad = min(comida_atrapada * 2, 25)
    energia = -10 
    hambre = -5

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)
    if not mascota:
        return jsonify({"success": False, "error": "Mascota no encontrada"}), 404

    id_mascota = mascota[0] if isinstance(mascota, tuple) else mascota['id_mascota']

  
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        UPDATE mascotas
        SET
        experiencia = experiencia + %s,
        dinero = dinero + %s,
        felicidad = LEAST(GREATEST(felicidad + %s, 0), 100),
        energia = LEAST(GREATEST(energia + %s, 0), 100),
        hambre = LEAST(GREATEST(hambre + %s, 0), 100)
        WHERE id_mascota = %s
        """,
        (experiencia, dinero, felicidad, energia, hambre, id_mascota)
    )

    log_texto = f"🐍 Snake Arcade: {puntos} pts! Ganó {dinero} monedas y {experiencia} EXP."
    cursor.execute(
        """
        INSERT INTO historial_acciones (id_mascota, accion)
        VALUES (%s, %s)
        """,
        (id_mascota, log_texto)
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    return jsonify({
        "success": True,
        "exp": experiencia,
        "dinero": dinero,
        "felicidad": felicidad
    })

def agregar_experiencia(cursor, id_mascota, exp_ganada=100):
    cursor.execute(
        "SELECT experiencia, nivel, dinero FROM mascotas WHERE id_mascota = %s",
        (id_mascota,),
    )
    mascota = cursor.fetchone()

    exp_actual = mascota["experiencia"] or 0
    nivel_actual = mascota["nivel"] or 1
    dinero_actual = mascota["dinero"] or 0

    nueva_exp = exp_actual + exp_ganada
    subio_nivel = False

    exp_por_nivel = 1000

    while nueva_exp >= exp_por_nivel:
        nueva_exp -= exp_por_nivel
        nivel_actual += 1
        dinero_actual += 500  
        subio_nivel = True

    cursor.execute(
        """
        UPDATE mascotas 
        SET experiencia = %s, nivel = %s, dinero = %s 
        WHERE id_mascota = %s
        """,
        (nueva_exp, nivel_actual, dinero_actual, id_mascota),
    )

    return {
        "subio_nivel": subio_nivel,
        "nivel": nivel_actual,
        "exp": nueva_exp,
        "dinero": dinero_actual,
    }



@app.route("/inventario")
def inventario():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT nombre_objeto, cantidad, permanente, equipado
        FROM inventario
        WHERE id_mascota=%s
        ORDER BY nombre_objeto
        """,
        (mascota[0],),
    )

    objetos = cursor.fetchall()
    cursor.close()
    conexion.close()

    return render_template("inventario.html", mascota=mascota, objetos=objetos)



@app.route("/usar/<nombre>", methods=["POST"])
def usar(nombre):
    if "id_usuario" not in session:
        return jsonify({"mensaje": "❌ Sesión no iniciada"}), 401

    try:
        conexion = conectar()
        cursor = conexion.cursor(buffered=True, dictionary=True)

       
        cursor.execute(
            "SELECT id_mascota, hambre FROM mascotas WHERE id_usuario=%s",
            (session["id_usuario"],),
        )
        mascota_data = cursor.fetchone()

        if not mascota_data:
            cursor.close()
            conexion.close()
            return jsonify({"mensaje": "❌ No existe mascota"}), 404

        id_mascota = mascota_data["id_mascota"]
        hambre_actual = mascota_data["hambre"] or 0

      
        cursor.execute(
            """
            SELECT cantidad, permanente
            FROM inventario
            WHERE id_mascota=%s AND nombre_objeto=%s
            """,
            (id_mascota, nombre),
        )
        objeto = cursor.fetchone()

        if not objeto:
            cursor.close()
            conexion.close()
            return jsonify({"mensaje": "❌ Objeto no encontrado"}), 404

        cantidad = objeto["cantidad"]
        permanente = objeto["permanente"]

        if permanente == 1:
            cursor.close()
            conexion.close()
            return jsonify(
                {
                    "mensaje": (
                        "✨ Este accesorio no se consume. Equípalo desde tu"
                        " inventario 🎩"
                    )
                }
            )

        # . Validar si la mascota está llena
        if (
            nombre in ["Croquetas", "Carne", "Pescado", "Lechuga"]
            and hambre_actual >= 100
        ):
            cursor.close()
            conexion.close()
            return jsonify(
                {
                    "lleno": True,
                    "mensaje": "🤢 ¡Estoy super lleno, no me cabe nada más!",
                }
            )

        mensajes = {
            "Croquetas": "🍪 ¡Delicioso! Mi pancita está feliz 🐾",
            "Carne": "🥩 ¡Qué rica comida! Estoy muy contento ❤️",
            "Pescado": "🐟 ¡Me encanta el pescado! Gracias 💚",
            "Lechuga": "🥬 ¡Comida saludable! Me siento mejor 🌱",
            "Pelota": "⚽ ¡Vamos a jugar! Me divertí mucho ⭐",
            "Hueso": "🦴 ¡Mi premio favorito! 🐶",
            "Ratón de Juguete": "🐭 ¡Qué divertido jugar contigo!",
            "Medicina": "💊 Me siento mucho mejor ❤️",
            "Vitamina": "🧪 Tengo mucha energía ⚡",
        }

        efectos = {
            "Croquetas": "hambre=LEAST(hambre+20,100)",
            "Carne": (
                "hambre=LEAST(hambre+30,100), felicidad=LEAST(felicidad+10,100)"
            ),
            "Pescado": "hambre=LEAST(hambre+20,100)",
            "Lechuga": "hambre=LEAST(hambre+15,100), salud=LEAST(salud+10,100)",
            "Pelota": "felicidad=LEAST(felicidad+20,100)",
            "Hueso": "felicidad=LEAST(felicidad+15,100)",
            "Ratón de Juguete": "felicidad=LEAST(felicidad+20,100)",
            "Medicina": "salud=LEAST(salud+30,100)",
            "Vitamina": "energia=LEAST(energia+20,100)",
        }

    
        if nombre in efectos:
            cursor.execute(
                f"UPDATE mascotas SET {efectos[nombre]} WHERE id_mascota=%s",
                (id_mascota,),
            )

        if cantidad > 1:
            cursor.execute(
                """
                UPDATE inventario SET cantidad=cantidad-1 
                WHERE id_mascota=%s AND nombre_objeto=%s
                """,
                (id_mascota, nombre),
            )
        else:
            cursor.execute(
                """
                DELETE FROM inventario 
                WHERE id_mascota=%s AND nombre_objeto=%s
                """,
                (id_mascota, nombre),
            )

       
        cursor.execute(
            """
            INSERT INTO historial_acciones (id_mascota, accion) 
            VALUES (%s, %s)
            """,
            (id_mascota, f"Usó {nombre}"),
        )

       
        resultado_exp = agregar_experiencia(
            cursor, id_mascota, exp_ganada=100
        )

        conexion.commit()

   
        cursor.execute(
            """
            SELECT hambre, felicidad, energia, salud, dinero, nivel, experiencia 
            FROM mascotas WHERE id_mascota=%s
            """,
            (id_mascota,),
        )
        stats = cursor.fetchone()

        cursor.close()
        conexion.close()

        return jsonify(
            {
                "lleno": False,
                "mensaje": mensajes.get(nombre, "🐾 Me gustó mucho"),
                "hambre": stats["hambre"],
                "felicidad": stats["felicidad"],
                "energia": stats["energia"],
                "salud": stats["salud"],
                "dinero": stats["dinero"],
                "subio_nivel": resultado_exp["subio_nivel"],
                "nivel": stats["nivel"],
                "exp": stats["experiencia"],
            }
        )

    except Exception as e:
        print("❌ ERROR EN RUTA /USAR:", str(e))
        return jsonify({"mensaje": f"Error en servidor: {str(e)}"}), 500



@app.route("/actualizar_estado")
def actualizar_estado():
    if "id_usuario" not in session:
        return redirect("/")

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        UPDATE mascotas
        SET hambre=GREATEST(hambre-5,0),
            energia=GREATEST(energia-5,0),
            felicidad=GREATEST(felicidad-3,0)
        WHERE id_usuario=%s
        """,
        (session["id_usuario"],),
    )

    conexion.commit()
    cursor.close()
    conexion.close()

    return redirect("/juego")




@app.route("/logout", methods=["POST", "GET"])
def logout():
    if "id_usuario" in session:
        mascota = obtener_mascota(session["id_usuario"])
        if mascota:
            
            resetear_tiempo_mascota(mascota[0])

    session.clear()
    return redirect("/")


@app.route("/veterinario")
def veterinario():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    actualizar_estado_mascota(mascota[0])
    mascota = obtener_mascota(id_usuario)

    
    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT *
        FROM tienda
        WHERE categoria = 'Salud' OR nombre IN ('Medicina', 'Vitamina')
        """
    )
    productos_salud = cursor.fetchall()

    
    cursor.execute(
        """
        SELECT nombre_objeto, cantidad
        FROM inventario
        WHERE id_mascota=%s AND cantidad > 0
        """,
        (mascota[0],)
    )
    inventario = cursor.fetchall()

    cursor.close()
    conexion.close()

    # Generar sugerencia del veterinario basada en el inventario
    alimentos = [item[0] for item in inventario if item[0] in ['Croquetas', 'Carne', 'Pescado', 'Lechuga']]
    if alimentos:
        sugerencia_comida = f"Veo que tienes {alimentos[0]} en tu inventario, ¡eso le ayudará a recuperar fuerzas!"
    else:
        sugerencia_comida = "No tienes mucha comida saludable en tu inventario. ¡Consigue un poco de Lechuga o Pescado en la tienda!"

   
    salud_mascota = mascota[7] # Índice del campo salud
    if salud_mascota == 0:
        mensaje_estado = "😿 No me siento nada bien, creo que veo la luz... :C"
    elif salud_mascota <= 30:
        mensaje_estado = "🤒 Me siento un poco débil y enfermo..."
    else:
        mensaje_estado = "😊 ¡Me siento bastante saludable, pero un chequeo nunca cae mal!"

    return render_template(
        "veterinario.html",
        mascota=mascota,
        productos_salud=productos_salud,
        sugerencia_comida=sugerencia_comida,
        mensaje_estado=mensaje_estado
    )


@app.route("/curar_veterinario")
def curar_veterinario():
   
    if "id_usuario" not in session:
        return redirect("/")

    mascota = obtener_mascota(session["id_usuario"])
    if not mascota:
        return redirect("/juego")

    id_mascota = mascota[0]
    dinero = mascota[8] 
    if dinero >= 10:
        conexion = conectar()
        cursor = conexion.cursor(buffered=True)

        cursor.execute(
            """
            UPDATE mascotas
            SET salud = LEAST(salud + 25, 100),
                felicidad = LEAST(felicidad + 10, 100),
                dinero = dinero - 10
            WHERE id_mascota = %s
            """,
            (id_mascota,)
        )

        cursor.execute(
            """
            INSERT INTO historial_acciones (id_mascota, accion)
            VALUES (%s, %s)
            """,
            (id_mascota, "Recibió atención veterinaria (-10 monedas)")
        )

        conexion.commit()
        cursor.close()
        conexion.close()

        flash("🩺 ¡El Dr. Peluditos atendió a tu mascota! Recupeó +25 de Salud y +10 de Felicidad.", "success")
    else:
        flash("💰 No tienes suficientes monedas para la consulta del veterinario (cuesta 10 monedas).", "error")

    return redirect("/veterinario")



@app.route("/juego_gato")
def juego_gato():
    if "id_usuario" not in session:
        return redirect("/")

    id_usuario = session["id_usuario"]
    mascota = obtener_mascota(id_usuario)

    if not mascota:
        return redirect("/juego")

    
    if mascota[6] <= 15:
        return render_template("sin_energia.html", mascota=mascota)

    return render_template("gato.html", mascota=mascota)


@app.route("/ganar_gato", methods=["POST"])
def ganar_gato():
    
    if "id_usuario" not in session:
        return jsonify({"error": "No autorizado"}), 401

    mascota = obtener_mascota(session["id_usuario"])
    if mascota:
        conexion = conectar()
        cursor = conexion.cursor(buffered=True)
        
        
        cursor.execute("""
            UPDATE mascotas 
            SET dinero = dinero + 15,
                felicidad = LEAST(felicidad + 10, 100)
            WHERE id_mascota = %s
        """, (mascota[0],))
        
        conexion.commit()
        cursor.close()
        conexion.close()
        
        return jsonify({"mensaje": "¡Ganaste +15 monedas y +10 de felicidad!"})
    
    return jsonify({"error": "Mascota no encontrada"}), 404
#

if __name__ == "__main__":
    app.run(debug=True)