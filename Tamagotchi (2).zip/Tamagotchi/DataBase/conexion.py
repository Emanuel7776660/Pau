import mysql.connector


def conectar():

    conexion = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="tamagotchi",
        port=3306
    )

    return conexion


if __name__ == "__main__":

    try:
        conexion = conectar()

        print("✅ Conexión exitosa a MySQL")

        conexion.close()

    except Exception as e:

        print("❌ Error de conexión:")
        print(e)