from flask import Flask, render_template, request, session, redirect, flash
from DataBase.conexion import conectar
import random


app = Flask(__name__)
app.secret_key = "tamagotchi_secreto"


# =========================
# FUNCIONES AUXILIARES
# =========================

def obtener_mascota(id_usuario):

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT *
        FROM mascotas
        WHERE id_usuario=%s
        LIMIT 1
        """,
        (id_usuario,)
    )

    mascota = cursor.fetchone()

    cursor.close()
    conexion.close()

    return mascota



def cerrar(conexion, cursor):

    cursor.close()
    conexion.close()

# actualizar estado de la mascota
def actualizar_estado_mascota(id_mascota):

    conexion=conectar()

    cursor=conexion.cursor(buffered=True)


    cursor.execute(
        """
        UPDATE mascotas
        SET
        hambre=GREATEST(hambre-5,0),
        energia=GREATEST(energia-3,0),
        felicidad=GREATEST(felicidad-2,0)
        WHERE id_mascota=%s
        """,
        (id_mascota,)
    )


    conexion.commit()

    cursor.close()
    conexion.close()
# =========================
# INICIO
# =========================

@app.route("/")
def inicio():

    return render_template("login.html")



# =========================
# LOGIN
# =========================

@app.route("/login", methods=["POST"])
def login():

    correo = request.form["correo"]
    password = request.form["password"]

    conexion = conectar()
    cursor = conexion.cursor(buffered=True)


    cursor.execute(
        """
        SELECT id_usuario, nombre
        FROM usuarios
        WHERE correo=%s
        AND password=%s
        """,
        (correo,password)
    )


    usuario = cursor.fetchone()


    if usuario:

        session["id_usuario"] = usuario[0]
        session["nombre"] = usuario[1]


        cursor.close()
        conexion.close()


        mascota = obtener_mascota(usuario[0])


        if mascota:

            return redirect("/juego")


        return render_template(
            "seleccion.html",
            nombre=usuario[1]
        )


    cursor.close()
    conexion.close()


    flash(
        "Correo o contraseña incorrectos.",
        "error"
    )


    return redirect("/")

# =========================
# REGISTRO
# =========================

@app.route("/registro", methods=["GET","POST"])
def registro():

    if request.method == "POST":

        nombre = request.form["nombre"]
        edad = request.form["edad"]
        correo = request.form["correo"]
        password = request.form["password"]


        conexion = conectar()
        cursor = conexion.cursor(buffered=True)


        cursor.execute(
            """
            INSERT INTO usuarios
            (nombre,edad,correo,password)
            VALUES (%s,%s,%s,%s)
            """,
            (
                nombre,
                edad,
                correo,
                password
            )
        )


        conexion.commit()

        cursor.close()
        conexion.close()


        return redirect("/")


    return render_template("registro.html")



# =========================
# CREAR MASCOTA
# =========================

@app.route("/crear_mascota", methods=["POST"])
def crear_mascota():

    tipo = request.form["tipo"]
    nombre_mascota = request.form["nombre_mascota"]

    id_usuario = session["id_usuario"]


    conexion = conectar()
    cursor = conexion.cursor(buffered=True)


    cursor.execute(
        """
        INSERT INTO mascotas
        (id_usuario,tipo,nombre_mascota)
        VALUES (%s,%s,%s)
        """,
        (
            id_usuario,
            tipo,
            nombre_mascota
        )
    )


    conexion.commit()


    cursor.close()
    conexion.close()


    return render_template(
        "historia.html",
        tipo=tipo,
        nombre=nombre_mascota
    )



# =========================
# JUEGO PRINCIPAL
# =========================

@app.route("/juego")
def juego():

    if "id_usuario" not in session:
        return redirect("/login")


    id_usuario=session["id_usuario"]


    mascota=obtener_mascota(id_usuario)


    if not mascota:
        return redirect("/elegir_mascota")


    actualizar_estado_mascota(mascota[0])


    mascota=obtener_mascota(id_usuario)



    hambre=mascota[4]
    felicidad=mascota[5]
    energia=mascota[6]
    salud=mascota[7]



    if hambre<=20:

        mensaje="😿 Tengo mucha hambre... ¿me das algo rico?"

    elif energia<=20:

        mensaje="😴 Estoy muy cansado, necesito dormir"

    elif felicidad<=20:

        mensaje="🥺 Estoy triste, juega conmigo"

    elif salud<=20:

        mensaje="🤒 No me siento muy bien"

    else:

        mensaje="😊 Estoy muy feliz contigo, gracias por cuidarme"



    return render_template(
        "juego.html",
        mascota=mascota,
        mensaje=mensaje
    )
# =========================
# ALIMENTAR
# =========================

@app.route("/alimentar")
def alimentar():

    id_usuario = session["id_usuario"]

    mascota = obtener_mascota(id_usuario)


    if mascota:

        id_mascota = mascota[0]
        dinero = mascota[9]


        if dinero >= 10:

            conexion = conectar()
            cursor = conexion.cursor(buffered=True)


            cursor.execute(
                """
                UPDATE mascotas
                SET 
                hambre=LEAST(hambre+20,100),
                felicidad=LEAST(felicidad+5,100),
                dinero=dinero-10
                WHERE id_mascota=%s
                """,
                (id_mascota,)
            )


            cursor.execute(
                """
                INSERT INTO historial_acciones
                (id_mascota,accion)
                VALUES (%s,%s)
                """,
                (
                    id_mascota,
                    "Comió alimento (-10 monedas)"
                )
            )


            conexion.commit()

            cursor.close()
            conexion.close()
        else:

            return """
            <h2>😿 Tu mascota no tiene suficiente dinero</h2>
            <a href="/juego">Volver</a>
            """
    return redirect("/juego")
# =========================
# DORMIR
# =========================

@app.route("/dormir")
def dormir():

    id_usuario = session["id_usuario"]

    mascota = obtener_mascota(id_usuario)


    if mascota:

        id_mascota = mascota[0]


        conexion = conectar()
        cursor = conexion.cursor(buffered=True)


        cursor.execute(
            """
            UPDATE mascotas
            SET energia=LEAST(energia+20,100),
                felicidad=LEAST(felicidad+5,100)
            WHERE id_mascota=%s
            """,
            (id_mascota,)
        )


        cursor.execute(
            """
            INSERT INTO historial_acciones
            (id_mascota,accion)
            VALUES (%s,%s)
            """,
            (
                id_mascota,
                "Durmió"
            )
        )


        conexion.commit()

        cursor.close()
        conexion.close()


    return redirect("/juego")



# =========================
# MENU DE JUEGOS
# =========================

@app.route("/juegos")
def juegos():

    mascota = obtener_mascota(
        session["id_usuario"]
    )


    return render_template(
        "juegos.html",
        mascota=mascota
    )



# =========================
# JUEGO DE PALABRAS
# =========================

# =====================================
# JUEGO PALABRAS
# =====================================


preguntas = [

    ("Animal que dice miau", "gato"),

    ("Animal que dice guau", "perro"),

    ("Objeto para jugar", "juguete"),

    ("Comida de mascotas", "comida"),

    ("Animal que tiene rayas", "tigre"),

    ("Lugar donde duerme una mascota", "cama"),

    ("Animal que vuela y tiene plumas", "ave"),

    ("Animal conocido como el rey de la selva", "leon"),

    ("Animal que vive en el agua y nada", "pez"),

    ("Fruta amarilla que comen los monos", "platano"),

    ("Color del pasto", "verde"),

    ("Color del cielo en un día despejado", "azul"),

    ("Objeto que sirve para escribir", "lapiz"),

    ("Objeto donde guardamos libros", "estante"),

    ("Lugar donde estudian los niños", "escuela"),

    ("Persona que cuida animales", "veterinario"),

    ("Animal que tiene caparazón", "tortuga"),

    ("Animal que produce miel", "abeja"),

    ("Animal que salta y vive en charcos", "rana"),

    ("Animal que tiene una trompa larga", "elefante"),

    ("Animal que tiene ocho patas", "arana"),

    ("Parte del cuerpo que usamos para caminar", "pie"),

    ("Parte del cuerpo que usamos para ver", "ojo"),

    ("Objeto que usamos para dormir", "almohada"),

    ("Lugar donde compramos productos", "tienda"),

    ("Algo que usamos cuando llueve", "paraguas"),

    ("Objeto que usamos para jugar videojuegos", "control"),

    ("Comida italiana famosa con queso", "pizza"),

    ("Bebida que toman muchas personas por la mañana", "cafe"),

    ("Estrella que ilumina la Tierra", "sol")

]



@app.route("/juego_palabras", methods=["GET","POST"])
def juego_palabras():


    # =========================
    # NUEVA PREGUNTA
    # =========================

    if request.method == "GET":


        pregunta = random.choice(preguntas)


        session["respuesta"] = pregunta[1]


        return render_template(
            "palabras.html",
            pregunta=pregunta[0]
        )



    # =========================
    # RESPUESTA DEL JUGADOR
    # =========================


    respuesta = request.form["respuesta"].lower()



    if respuesta == session.get("respuesta"):



        conexion = conectar()

        cursor = conexion.cursor(buffered=True)



        cursor.execute(
            """
            SELECT id_mascota
            FROM mascotas
            WHERE id_usuario=%s
            LIMIT 1
            """,
            (
                session["id_usuario"],
            )
        )


        mascota = cursor.fetchone()



        if mascota:


            id_mascota = mascota[0]



            cursor.execute(
                """
                UPDATE mascotas

                SET

                experiencia = experiencia + 10,

                dinero = dinero + 15,

                felicidad = LEAST(felicidad + 10,100)

                WHERE id_mascota=%s

                """,
                (
                    id_mascota,
                )
            )



            cursor.execute(
                """
                INSERT INTO historial_acciones

                (
                id_mascota,
                accion
                )

                VALUES

                (%s,%s)

                """,
                (
                    id_mascota,
                    "Ganó 15 monedas jugando palabras"
                )
            )



            conexion.commit()



        cursor.close()

        conexion.close()



        mensaje = """

🎉 ¡Excelente!

🐾 Tu mascota está muy feliz

Ganaste:

⭐ +10 experiencia

💰 +15 monedas

❤️ +10 felicidad

"""

        resultado = "correcto"



    else:



        mensaje = """

😿 Casi lo lograste

🐾 Tu mascota sigue confiando en ti

Intenta nuevamente,
seguro podrás conseguirlo ⭐

"""

        resultado = "incorrecto"




    return render_template(
        "resultado.html",
        mensaje=mensaje,
        resultado=resultado
    )


# =========================
# TIENDA
# =========================
@app.route("/tienda")
def tienda():

    id_usuario = session["id_usuario"]

    mascota = obtener_mascota(id_usuario)


    conexion = conectar()

    cursor = conexion.cursor(buffered=True)


    cursor.execute(
        """
        SELECT *
        FROM tienda
        """
    )


    productos = cursor.fetchall()


    cursor.close()
    conexion.close()



    mensajes = [

        "🐾 ¡Vamos a comprar algo divertido!",

        "✨ Espero encontrar algo rico",

        "🎁 Me gustan los regalos",

        "💚 Gracias por cuidarme",

        "🛒 ¿Qué compraremos hoy?"

    ]
    mensaje = random.choice(mensajes)
    return render_template(
        "tienda.html",
        mascota=mascota,
        productos=productos,
        mensaje=mensaje
    )

@app.route("/comprar/<int:id_producto>", methods=["POST"])
def comprar(id_producto):

    id_usuario=session["id_usuario"]

    mascota=obtener_mascota(id_usuario)

    conexion=conectar()
    cursor=conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT nombre,precio
        FROM tienda
        WHERE id_producto=%s
        """,
        (id_producto,)
    )

    producto=cursor.fetchone()

    if not producto:
        cursor.close()
        conexion.close()
        return "Producto no encontrado"


    nombre=producto[0]
    precio=producto[1]
    dinero=mascota[8]


    if dinero < precio:

        cursor.close()
        conexion.close()

        return """
        <h2>😿 No tienes suficientes monedas</h2>
        <a href="/tienda">Volver a la tienda</a>
        """


    id_mascota=mascota[0]


    cursor.execute(
        """
        UPDATE mascotas
        SET dinero=dinero-%s
        WHERE id_mascota=%s
        """,
        (
            precio,
            id_mascota
        )
    )


    cursor.execute(
        """
        SELECT cantidad
        FROM inventario
        WHERE id_mascota=%s
        AND nombre_objeto=%s
        """,
        (
            id_mascota,
            nombre
        )
    )


    objeto=cursor.fetchone()


    if objeto:

        cursor.execute(
            """
            UPDATE inventario
            SET cantidad=cantidad+1
            WHERE id_mascota=%s
            AND nombre_objeto=%s
            """,
            (
                id_mascota,
                nombre
            )
        )

    else:

        cursor.execute(
            """
            INSERT INTO inventario
            (
            id_mascota,
            nombre_objeto,
            cantidad
            )
            VALUES(%s,%s,1)
            """,
            (
                id_mascota,
                nombre
            )
        )


    cursor.execute(
        """
        INSERT INTO historial_acciones
        (
        id_mascota,
        accion
        )
        VALUES(%s,%s)
        """,
        (
            id_mascota,
            "Compró "+nombre
        )
    )


    conexion.commit()

    cursor.close()
    conexion.close()


    return redirect("/tienda")
## =========================
# AVENTURA TAMAGOTCHI
# =========================


@app.route("/aventura")
def aventura():

    id_usuario = session["id_usuario"]

    mascota = obtener_mascota(id_usuario)


    eventos = [

        "🌲 Caminaste por un bosque misterioso",

        "🐾 Encontraste huellas extrañas",

        "💎 Viste algo brillante entre los árboles",

        "🌈 Llegaste a un lugar mágico",

        "⚔️ Apareció un pequeño desafío",

        "🦋 Tu mascota encontró un camino secreto"

    ]


    evento = random.choice(eventos)


    return render_template(
        "aventura.html",
        mascota=mascota,
        evento=evento
    )





@app.route("/accion_aventura/<accion>")
def accion_aventura(accion):


    id_usuario = session["id_usuario"]


    mascota = obtener_mascota(id_usuario)



    if mascota is None:

        return redirect("/juego")



    id_mascota = mascota[0]



    # Valores iniciales

    experiencia = 0
    dinero = 0
    felicidad = 0
    energia = 0
    hambre = 0


    texto = ""



    if accion == "explorar":


        experiencia = 10
        dinero = 5
        felicidad = 5
        energia = -10
        hambre = -5


        texto = "🌲 Exploró el bosque y encontró monedas"



    elif accion == "reto":


        experiencia = 20
        dinero = 15
        felicidad = 3
        energia = -15
        hambre = -10


        texto = "⚔️ Superó un reto y ganó una recompensa"



    elif accion == "tesoro":


        experiencia = 15
        dinero = 30
        felicidad = 10
        energia = -5


        texto = "💎 Encontró un tesoro escondido"



    elif accion == "descansar":


        felicidad = 5
        energia = 20


        texto = "💤 Descansó y recuperó energía"





    conexion = conectar()

    cursor = conexion.cursor(buffered=True)



    cursor.execute(
        """
        UPDATE mascotas

        SET

        experiencia = experiencia + %s,

        dinero = dinero + %s,

        felicidad = LEAST(GREATEST(felicidad + %s,0),100),

        energia = LEAST(GREATEST(energia + %s,0),100),

        hambre = LEAST(GREATEST(hambre + %s,0),100)

        WHERE id_mascota=%s

        """,
        (
            experiencia,
            dinero,
            felicidad,
            energia,
            hambre,
            id_mascota
        )
    )




    cursor.execute(
        """
        INSERT INTO historial_acciones

        (
        id_mascota,
        accion
        )

        VALUES

        (%s,%s)

        """,
        (
            id_mascota,
            texto
        )
    )



    conexion.commit()


    cursor.close()

    conexion.close()



    return redirect("/aventura")


# =========================
# INVENTARIO
# =========================

@app.route("/inventario")
def inventario():

    id_usuario=session["id_usuario"]

    mascota=obtener_mascota(id_usuario)

    conexion=conectar()
    cursor=conexion.cursor(buffered=True)

    cursor.execute(
        """
        SELECT nombre_objeto,cantidad
        FROM inventario
        WHERE id_mascota=%s
        ORDER BY nombre_objeto
        """,
        (mascota[0],)
    )

    objetos=cursor.fetchall()

    cursor.close()
    conexion.close()

    return render_template(
        "inventario.html",
        mascota=mascota,
        objetos=objetos
    )

# =========================
# USAR OBJETO INVENTARIO
# =========================

# =========================
# USAR OBJETO
# =========================

@app.route("/usar/<nombre>", methods=["POST"])
def usar(nombre):

    id_usuario=session["id_usuario"]

    mascota=obtener_mascota(id_usuario)

    if not mascota:
        return "No existe mascota"


    id_mascota=mascota[0]


    conexion=conectar()
    cursor=conexion.cursor(buffered=True)



    cursor.execute(
        """
        SELECT cantidad
        FROM inventario
        WHERE id_mascota=%s
        AND nombre_objeto=%s
        """,
        (
            id_mascota,
            nombre
        )
    )


    objeto=cursor.fetchone()


    if not objeto:
        cursor.close()
        conexion.close()
        return "Objeto no encontrado"



    cantidad=objeto[0]



    mensajes={
        "Croquetas":"🍪 ¡Delicioso! Mi pancita está feliz 🐾",
        "Carne":"🥩 ¡Qué rica comida! Estoy muy contento ❤️",
        "Pescado":"🐟 ¡Me encanta el pescado! Gracias 💚",
        "Lechuga":"🥬 ¡Comida saludable! Me siento mejor 🌱",
        "Pelota":"⚽ ¡Vamos a jugar! Me divertí mucho ⭐",
        "Hueso":"🦴 ¡Mi premio favorito! 🐶",
        "Ratón de Juguete":"🐭 ¡Qué divertido jugar contigo!",
        "Medicina":"💊 Me siento mucho mejor ❤️",
        "Vitamina":"🧪 Tengo mucha energía ⚡",
        "Collar Rosa":"📿 ¡Me veo increíble!",
        "Sombrero":"🎩 ¡Mira mi nuevo estilo!"
    }



    efectos={

        "Croquetas":(
            "hambre=LEAST(hambre+20,100)"
        ),

        "Carne":(
            "hambre=LEAST(hambre+30,100), felicidad=LEAST(felicidad+10,100)"
        ),

        "Pescado":(
            "hambre=LEAST(hambre+20,100)"
        ),

        "Lechuga":(
            "hambre=LEAST(hambre+15,100), salud=LEAST(salud+10,100)"
        ),

        "Pelota":(
            "felicidad=LEAST(felicidad+20,100)"
        ),

        "Hueso":(
            "felicidad=LEAST(felicidad+15,100)"
        ),

        "Ratón de Juguete":(
            "felicidad=LEAST(felicidad+20,100)"
        ),

        "Medicina":(
            "salud=LEAST(salud+30,100)"
        ),

        "Vitamina":(
            "energia=LEAST(energia+20,100)"
        )

    }



    if nombre in efectos:


        cursor.execute(
            f"""
            UPDATE mascotas
            SET {efectos[nombre]}
            WHERE id_mascota=%s
            """,
            (id_mascota,)
        )



    if cantidad>1:


        cursor.execute(
            """
            UPDATE inventario
            SET cantidad=cantidad-1
            WHERE id_mascota=%s
            AND nombre_objeto=%s
            """,
            (
                id_mascota,
                nombre
            )
        )


    else:


        cursor.execute(
            """
            DELETE FROM inventario
            WHERE id_mascota=%s
            AND nombre_objeto=%s
            """,
            (
                id_mascota,
                nombre
            )
        )



    cursor.execute(
        """
        INSERT INTO historial_acciones
        (
        id_mascota,
        accion
        )
        VALUES(%s,%s)
        """,
        (
            id_mascota,
            "Usó "+nombre
        )
    )



    conexion.commit()

    cursor.close()
    conexion.close()



    return {
        "mensaje":mensajes.get(
            nombre,
            "🐾 Me gustó mucho"
        )
    }
# =========================
# ACTUALIZAR ESTADO
# =========================

@app.route("/actualizar_estado")
def actualizar_estado():


    conexion = conectar()
    cursor = conexion.cursor(buffered=True)


    cursor.execute(
        """
        UPDATE mascotas
        SET hambre=GREATEST(hambre-5,0),
            energia=GREATEST(energia-5,0),
            felicidad=GREATEST(felicidad-3,0)
        WHERE id_usuario=%s
        """,
        (
            session["id_usuario"],
        )
    )


    conexion.commit()

    cursor.close()
    conexion.close()


    return redirect("/juego")



# =========================
# EJECUTAR APP
# =========================

if __name__ == "__main__":

    app.run(debug=True)