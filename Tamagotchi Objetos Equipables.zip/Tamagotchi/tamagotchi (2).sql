-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-08-2026 a las 20:03:24
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tamagotchi`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_acciones`
--

CREATE TABLE `historial_acciones` (
  `id_accion` int(11) NOT NULL,
  `id_mascota` int(11) NOT NULL,
  `accion` varchar(100) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historial_acciones`
--

INSERT INTO `historial_acciones` (`id_accion`, `id_mascota`, `accion`, `fecha`) VALUES
(1, 3, 'Alimento recibido', '2026-07-11 07:02:36'),
(2, 3, 'Alimento recibido', '2026-07-11 07:02:40'),
(3, 3, 'Alimento recibido', '2026-07-11 07:03:12'),
(4, 3, 'Alimento recibido', '2026-07-11 07:04:14'),
(5, 3, 'Alimento recibido', '2026-07-11 07:06:24'),
(6, 3, 'Alimento recibido', '2026-07-11 07:06:28'),
(7, 3, 'La mascota comio alimento', '2026-07-11 07:09:00'),
(8, 3, 'La mascota comio alimento', '2026-07-11 07:09:05'),
(9, 3, 'La mascota comio alimento', '2026-07-11 07:09:09'),
(10, 3, '🎁 Encontraste un tesoro escondido', '2026-07-11 07:31:39'),
(11, 3, '⚔️ Superaste un reto junto a tu mascota', '2026-07-11 07:31:41'),
(12, 3, '⚔️ Superaste un reto junto a tu mascota', '2026-07-11 07:31:42'),
(13, 3, '🌲 Exploraste el bosque y encontraste algo interesante', '2026-07-11 07:31:43'),
(14, 3, '💤 Tu mascota descansó', '2026-07-11 07:31:45'),
(15, 3, '⚔️ Superaste un reto junto a tu mascota', '2026-07-11 07:31:49'),
(16, 3, '🎁 Encontraste un tesoro escondido', '2026-07-11 07:31:51'),
(17, 3, '🌲 Exploraste el bosque y encontraste algo interesante', '2026-07-11 07:31:54'),
(18, 3, '💤 Tu mascota descansó', '2026-07-11 07:31:55'),
(19, 3, '⚔️ Superaste un reto junto a tu mascota', '2026-07-11 07:31:58'),
(20, 3, '🎁 Encontraste un tesoro escondido', '2026-07-11 07:31:59'),
(21, 4, '⚔️ Superaste un reto junto a tu mascota', '2026-07-11 07:39:44'),
(22, 4, '🎁 Encontraste un tesoro escondido', '2026-07-11 07:39:46'),
(23, 4, '🌲 Exploraste el bosque y encontraste algo interesante', '2026-07-11 07:39:48'),
(24, 4, 'Durmió', '2026-07-11 07:39:56'),
(25, 5, 'Comió alimento', '2026-07-12 01:04:00'),
(26, 5, 'Durmió', '2026-07-12 01:04:12'),
(27, 5, 'Comió alimento', '2026-07-12 01:04:21'),
(28, 5, 'Comió alimento', '2026-07-12 01:07:30'),
(29, 5, '🌲 Exploraste el bosque y encontraste algo interesante', '2026-07-12 01:08:37'),
(30, 5, '⚔️ Superaste un reto junto a tu mascota', '2026-07-12 01:08:38'),
(31, 5, '🎁 Encontraste un tesoro escondido', '2026-07-12 01:08:39'),
(32, 1, '⚔️ Superaste un reto junto a tu mascota', '2026-07-14 04:56:11'),
(33, 1, '🌲 Exploraste el bosque y encontraste algo interesante', '2026-07-14 04:56:13'),
(34, 1, '💤 Tu mascota descansó', '2026-07-14 04:56:14'),
(35, 1, '⚔️ Superaste un reto junto a tu mascota', '2026-07-14 05:11:01'),
(36, 1, '⚔️ Superaste un reto junto a tu mascota', '2026-07-14 05:11:03'),
(37, 1, '⚔️ Superaste un reto junto a tu mascota', '2026-07-14 05:11:04'),
(38, 1, '⚔️ Superaste un reto junto a tu mascota', '2026-07-14 05:11:05'),
(39, 1, '⚔️ Superaste un reto junto a tu mascota', '2026-07-14 05:11:06'),
(40, 1, '⚔️ Superaste un reto junto a tu mascota', '2026-07-14 05:11:07'),
(41, 1, '🌲 Exploraste el bosque y encontraste algo interesante', '2026-07-14 05:11:08'),
(42, 1, '⚔️ Superaste un reto junto a tu mascota', '2026-07-14 05:11:09'),
(43, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-14 05:29:53'),
(44, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-14 05:29:56'),
(45, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-14 05:29:58'),
(46, 1, '⚔️ Superó un reto y ganó una recompensa', '2026-07-14 05:29:59'),
(47, 1, '💎 Encontró un tesoro escondido', '2026-07-14 05:30:01'),
(48, 1, '💤 Descansó y recuperó energía', '2026-07-14 05:30:03'),
(49, 1, '💤 Descansó y recuperó energía', '2026-07-14 05:30:04'),
(50, 1, 'Ganó 15 monedas jugando palabras', '2026-07-14 05:33:21'),
(51, 1, 'Ganó 15 monedas jugando palabras', '2026-07-14 05:35:27'),
(52, 1, 'Ganó 15 monedas jugando palabras', '2026-07-14 05:35:27'),
(53, 1, 'Ganó 15 monedas jugando palabras', '2026-07-14 05:35:27'),
(54, 1, 'Ganó 15 monedas jugando palabras', '2026-07-14 05:35:39'),
(55, 6, 'Ganó 15 monedas jugando palabras', '2026-07-14 05:39:49'),
(56, 6, 'Ganó 15 monedas jugando palabras', '2026-07-14 05:47:40'),
(57, 7, 'Ganó 15 monedas jugando palabras', '2026-07-15 17:15:37'),
(58, 8, 'Ganó 15 monedas jugando palabras', '2026-07-15 17:23:24'),
(59, 8, 'Durmió', '2026-07-15 17:31:03'),
(60, 1, 'Compró Croquetas', '2026-07-24 03:04:57'),
(61, 1, 'Compró Croquetas', '2026-07-24 03:04:58'),
(62, 1, 'Compró Carne', '2026-07-24 03:05:01'),
(63, 1, 'Compró Croquetas', '2026-07-24 03:10:58'),
(64, 1, 'Compró Croquetas', '2026-07-24 03:10:59'),
(65, 1, 'Compró Croquetas', '2026-07-24 03:23:57'),
(66, 1, 'Compró Croquetas', '2026-07-24 03:23:58'),
(67, 1, 'Compró Croquetas', '2026-07-24 03:25:48'),
(68, 1, 'Compró Croquetas', '2026-07-24 03:25:50'),
(69, 1, 'Compró Croquetas', '2026-07-24 03:27:00'),
(70, 1, 'Compró Croquetas', '2026-07-24 03:27:02'),
(71, 1, 'Compró Hueso', '2026-07-24 03:27:17'),
(72, 1, 'Compró Hueso', '2026-07-24 03:27:19'),
(73, 1, 'Compró Pescado', '2026-07-24 03:27:20'),
(74, 1, 'Usó Croquetas', '2026-07-24 03:34:52'),
(75, 1, 'Usó Croquetas', '2026-07-24 03:34:54'),
(76, 1, 'Usó Croquetas', '2026-07-24 03:35:05'),
(77, 1, 'Usó Croquetas', '2026-07-24 03:35:06'),
(78, 1, 'Usó Croquetas', '2026-07-24 03:35:07'),
(79, 1, 'Usó Hueso', '2026-07-24 03:35:08'),
(80, 1, 'Usó Pescado', '2026-07-24 03:35:10'),
(81, 1, 'Usó Croquetas', '2026-07-24 03:41:46'),
(82, 1, 'Usó Hueso', '2026-07-24 03:41:48'),
(83, 1, 'Compró Croquetas', '2026-07-24 03:47:35'),
(84, 1, 'Compró Croquetas', '2026-07-24 03:47:36'),
(85, 1, 'Compró Croquetas', '2026-07-24 03:47:37'),
(86, 1, 'Usó Croquetas', '2026-07-24 03:47:45'),
(87, 1, 'Durmió', '2026-07-24 03:55:44'),
(88, 1, 'Durmió', '2026-07-24 03:55:49'),
(89, 1, 'Durmió', '2026-07-24 03:55:53'),
(90, 1, 'Usó Croquetas', '2026-07-24 03:59:25'),
(91, 1, 'Usó Croquetas', '2026-07-24 03:59:28'),
(92, 1, 'Durmió', '2026-07-24 04:01:54'),
(93, 1, 'Usó Pescado', '2026-07-27 17:22:28'),
(94, 1, 'Compró Carne', '2026-07-27 17:22:38'),
(95, 1, 'Compró Carne', '2026-07-27 17:22:39'),
(96, 1, 'Compró Carne', '2026-07-27 17:22:40'),
(97, 1, 'Compró Croquetas', '2026-07-27 17:22:42'),
(98, 1, 'Compró Croquetas', '2026-07-27 17:22:42'),
(99, 1, 'Usó Croquetas', '2026-07-27 17:23:00'),
(100, 1, 'Usó Croquetas', '2026-07-27 17:23:03'),
(101, 1, 'Usó Carne', '2026-07-27 17:23:06'),
(102, 1, 'Usó Carne', '2026-07-27 17:23:07'),
(103, 1, 'Usó Carne', '2026-07-27 17:23:07'),
(104, 1, 'Durmió', '2026-07-27 17:24:48'),
(105, 1, 'Durmió', '2026-07-27 17:24:51'),
(106, 1, 'Ganó 15 monedas jugando palabras', '2026-07-27 18:00:37'),
(107, 1, 'Ganó 15 monedas jugando palabras', '2026-07-27 18:00:53'),
(108, 1, 'Ganó 15 monedas jugando palabras', '2026-07-27 18:01:35'),
(109, 1, 'Ganó 15 monedas jugando palabras', '2026-07-27 18:01:42'),
(110, 1, 'Compró Croquetas', '2026-07-27 18:04:18'),
(111, 1, 'Compró Croquetas', '2026-07-27 18:04:19'),
(112, 1, 'Compró Croquetas', '2026-07-27 18:04:20'),
(113, 1, 'Compró Croquetas', '2026-07-27 18:04:21'),
(114, 1, 'Usó Croquetas', '2026-07-27 18:04:28'),
(115, 1, 'Usó Croquetas', '2026-07-27 18:04:29'),
(116, 1, 'Usó Croquetas', '2026-07-27 18:04:30'),
(117, 1, 'Usó Croquetas', '2026-07-27 18:04:31'),
(118, 1, 'Durmió', '2026-07-27 18:04:46'),
(119, 1, 'Durmió', '2026-07-27 18:04:49'),
(120, 11, '⚔️ Superó un reto y ganó una recompensa', '2026-07-27 18:20:47'),
(121, 11, '⚔️ Superó un reto y ganó una recompensa', '2026-07-27 18:20:48'),
(122, 11, '⚔️ Superó un reto y ganó una recompensa', '2026-07-27 18:20:49'),
(123, 11, '⚔️ Superó un reto y ganó una recompensa', '2026-07-27 18:20:50'),
(124, 11, '⚔️ Superó un reto y ganó una recompensa', '2026-07-27 18:20:50'),
(125, 11, '⚔️ Superó un reto y ganó una recompensa', '2026-07-27 18:20:50'),
(126, 11, '⚔️ Superó un reto y ganó una recompensa', '2026-07-27 18:20:50'),
(127, 11, '🌲 Exploró el bosque y encontró monedas', '2026-07-27 18:20:51'),
(128, 11, '💤 Descansó y recuperó energía', '2026-07-27 18:20:52'),
(129, 11, 'Compró Pescado', '2026-07-27 18:21:12'),
(130, 11, 'Compró Pescado', '2026-07-27 18:21:14'),
(131, 11, 'Compró Pescado', '2026-07-27 18:21:14'),
(132, 11, 'Compró Pescado', '2026-07-27 18:21:16'),
(133, 11, 'Usó Pescado', '2026-07-27 18:21:21'),
(134, 11, 'Usó Pescado', '2026-07-27 18:21:22'),
(135, 11, 'Usó Pescado', '2026-07-27 18:21:23'),
(136, 11, 'Usó Pescado', '2026-07-27 18:21:24'),
(137, 11, 'Durmió', '2026-07-27 18:21:29'),
(138, 11, 'Durmió', '2026-07-27 18:21:32'),
(139, 11, 'Durmió', '2026-07-27 18:21:35'),
(140, 11, 'Durmió', '2026-07-27 18:21:38'),
(141, 1, 'Compró Croquetas', '2026-07-27 18:38:11'),
(142, 1, 'Compró Croquetas', '2026-07-27 18:38:13'),
(143, 1, 'Compró Croquetas', '2026-07-27 18:38:13'),
(144, 1, 'Usó Croquetas', '2026-07-27 18:38:22'),
(145, 1, 'Usó Croquetas', '2026-07-27 18:38:23'),
(146, 1, 'Usó Croquetas', '2026-07-27 18:38:24'),
(147, 12, 'Ganó 15 monedas jugando palabras', '2026-07-27 18:40:53'),
(148, 12, 'Ganó 15 monedas jugando palabras', '2026-07-27 18:41:02'),
(149, 12, 'Ganó 15 monedas jugando palabras', '2026-07-27 18:41:12'),
(150, 12, 'Compró Hueso', '2026-07-27 18:41:47'),
(151, 12, 'Compró Hueso', '2026-07-27 18:41:53'),
(152, 12, 'Usó Hueso', '2026-07-27 18:42:09'),
(153, 12, 'Usó Hueso', '2026-07-27 18:42:10'),
(154, 1, 'Durmió', '2026-07-30 20:20:05'),
(155, 1, 'Durmió', '2026-07-30 20:20:08'),
(156, 1, 'Durmió', '2026-07-30 20:20:10'),
(157, 1, 'Durmió', '2026-07-30 20:20:33'),
(158, 1, 'Durmió', '2026-07-30 20:20:35'),
(159, 1, 'Durmió', '2026-07-30 20:20:38'),
(160, 1, 'Durmió', '2026-07-30 20:21:23'),
(161, 1, 'Durmió', '2026-07-30 20:21:26'),
(162, 1, 'Ganó 15 monedas jugando palabras', '2026-07-30 20:31:35'),
(163, 1, 'Ganó 15 monedas jugando palabras', '2026-07-30 20:31:53'),
(164, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:03'),
(165, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:03'),
(166, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:03'),
(167, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:03'),
(168, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:03'),
(169, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:04'),
(170, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:04'),
(171, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:04'),
(172, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:04'),
(173, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:04'),
(174, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:04'),
(175, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:05'),
(176, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:05'),
(177, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:05'),
(178, 1, '⚔️ Superó un reto y ganó una recompensa', '2026-07-30 20:32:06'),
(179, 1, '💎 Encontró un tesoro escondido', '2026-07-30 20:32:07'),
(180, 1, '💤 Descansó y recuperó energía', '2026-07-30 20:32:09'),
(181, 1, '⚔️ Superó un reto y ganó una recompensa', '2026-07-30 20:32:10'),
(182, 1, '⚔️ Superó un reto y ganó una recompensa', '2026-07-30 20:32:11'),
(183, 1, '🌲 Exploró el bosque y encontró monedas', '2026-07-30 20:32:16'),
(184, 1, 'Compró Sombrero', '2026-07-30 20:35:03'),
(185, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:23'),
(186, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:25'),
(187, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:26'),
(188, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:26'),
(189, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:27'),
(190, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:27'),
(191, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:27'),
(192, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:28'),
(193, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:28'),
(194, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:28'),
(195, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:28'),
(196, 1, '💤 Descansó y recuperó energía', '2026-08-01 17:10:29'),
(197, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:30'),
(198, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:30'),
(199, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:30'),
(200, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:30'),
(201, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:31'),
(202, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:31'),
(203, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:31'),
(204, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:31'),
(205, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:32'),
(206, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:32'),
(207, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:32'),
(208, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:33'),
(209, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:33'),
(210, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:33'),
(211, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:33'),
(212, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:34'),
(213, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:34'),
(214, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:34'),
(215, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:34'),
(216, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:35'),
(217, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:35'),
(218, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:10:35'),
(219, 1, 'Usó Sombrero', '2026-08-01 17:11:05'),
(220, 1, 'Compró Sombrero', '2026-08-01 17:13:02'),
(221, 1, 'Usó Sombrero', '2026-08-01 17:13:13'),
(222, 1, 'Compró Sombrero', '2026-08-01 17:18:18'),
(223, 1, 'Equipó Sombrero', '2026-08-01 17:18:26'),
(224, 1, 'Desequipó Sombrero', '2026-08-01 17:18:29'),
(225, 1, 'Equipó Sombrero', '2026-08-01 17:18:30'),
(226, 1, 'Desequipó Sombrero', '2026-08-01 17:18:32'),
(227, 1, 'Equipó Sombrero', '2026-08-01 17:22:28'),
(228, 1, 'Desequipó Sombrero', '2026-08-01 17:26:57'),
(229, 1, 'Equipó Sombrero', '2026-08-01 17:26:58'),
(230, 1, 'Desequipó Sombrero', '2026-08-01 17:27:37'),
(231, 1, 'Equipó Sombrero', '2026-08-01 17:27:43'),
(232, 1, 'Desequipó Sombrero', '2026-08-01 17:31:34'),
(233, 1, 'Equipó Sombrero', '2026-08-01 17:31:36'),
(234, 1, 'Desequipó Sombrero', '2026-08-01 17:31:47'),
(235, 1, 'Equipó Sombrero', '2026-08-01 17:31:48'),
(236, 1, 'Desequipó Sombrero', '2026-08-01 17:32:03'),
(237, 1, 'Equipó Sombrero', '2026-08-01 17:32:05'),
(238, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:28'),
(239, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:29'),
(240, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:29'),
(241, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:29'),
(242, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:29'),
(243, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:29'),
(244, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:30'),
(245, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:30'),
(246, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:30'),
(247, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:30'),
(248, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:31'),
(249, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:31'),
(250, 1, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:32:31'),
(251, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:32'),
(252, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:33'),
(253, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:33'),
(254, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:34'),
(255, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:34'),
(256, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:34'),
(257, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:34'),
(258, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:34'),
(259, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:34'),
(260, 1, '💎 Encontró un tesoro escondido', '2026-08-01 17:32:35'),
(261, 1, 'Compró Collar Rosa', '2026-08-01 17:32:45'),
(262, 1, 'Equipó Collar Rosa', '2026-08-01 17:32:54'),
(263, 1, 'Desequipó Sombrero', '2026-08-01 17:33:05'),
(264, 1, 'Desequipó Collar Rosa', '2026-08-01 17:33:07'),
(265, 1, 'Equipó Collar Rosa', '2026-08-01 17:33:08'),
(266, 1, 'Equipó Sombrero', '2026-08-01 17:41:26'),
(267, 1, 'Desequipó Collar Rosa', '2026-08-01 17:41:27'),
(268, 1, 'Desequipó Sombrero', '2026-08-01 17:41:28'),
(269, 1, 'Equipó Collar Rosa', '2026-08-01 17:41:29'),
(270, 1, 'Equipó Sombrero', '2026-08-01 17:41:30'),
(271, 1, 'Compró Lentes', '2026-08-01 17:51:46'),
(272, 1, 'Equipó Lentes', '2026-08-01 17:51:53'),
(273, 1, 'Desequipó Collar Rosa', '2026-08-01 17:57:21'),
(274, 1, 'Equipó Collar Rosa', '2026-08-01 17:57:59'),
(275, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:37'),
(276, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:38'),
(277, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:39'),
(278, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:39'),
(279, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:39'),
(280, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:39'),
(281, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:39'),
(282, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:40'),
(283, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:40'),
(284, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:40'),
(285, 13, '🌲 Exploró el bosque y encontró monedas', '2026-08-01 17:59:40'),
(286, 13, 'Compró Sombrero', '2026-08-01 18:00:01'),
(287, 13, 'Equipó Sombrero', '2026-08-01 18:00:10'),
(288, 14, '💎 Encontró un tesoro escondido', '2026-08-01 18:01:08'),
(289, 14, '💎 Encontró un tesoro escondido', '2026-08-01 18:01:08'),
(290, 14, '💎 Encontró un tesoro escondido', '2026-08-01 18:01:09'),
(291, 14, '💎 Encontró un tesoro escondido', '2026-08-01 18:01:09'),
(292, 14, '💎 Encontró un tesoro escondido', '2026-08-01 18:01:09'),
(293, 14, 'Compró Lentes', '2026-08-01 18:01:22'),
(294, 14, 'Equipó Lentes', '2026-08-01 18:01:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id_item` int(11) NOT NULL,
  `id_mascota` int(11) NOT NULL,
  `nombre_objeto` varchar(100) NOT NULL,
  `cantidad` int(11) DEFAULT 1,
  `equipado` tinyint(1) DEFAULT 0,
  `permanente` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id_item`, `id_mascota`, `nombre_objeto`, `cantidad`, `equipado`, `permanente`) VALUES
(18, 1, 'Sombrero', 1, 1, 1),
(19, 1, 'Collar Rosa', 1, 1, 1),
(20, 1, 'Lentes', 1, 1, 1),
(21, 13, 'Sombrero', 1, 1, 1),
(22, 14, 'Lentes', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascotas`
--

CREATE TABLE `mascotas` (
  `id_mascota` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `tipo` enum('Perro','Gato','Tortuga') NOT NULL,
  `nombre_mascota` varchar(50) DEFAULT NULL,
  `hambre` int(11) DEFAULT 100,
  `felicidad` int(11) DEFAULT 100,
  `energia` int(11) DEFAULT 100,
  `salud` int(11) DEFAULT 100,
  `dinero` int(11) DEFAULT 50,
  `nivel` int(11) DEFAULT 1,
  `experiencia` int(11) DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultima_actualizacion` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mascotas`
--

INSERT INTO `mascotas` (`id_mascota`, `id_usuario`, `tipo`, `nombre_mascota`, `hambre`, `felicidad`, `energia`, `salud`, `dinero`, `nivel`, `experiencia`, `fecha_creacion`, `ultima_actualizacion`) VALUES
(1, 3, 'Perro', 'pau', 0, 0, 0, 0, 180, 1, 1090, '2026-07-11 06:40:48', '2026-08-01 12:00:40'),
(2, 3, 'Perro', 'pau', 0, 37, 0, 100, 50, 1, 0, '2026-07-11 06:41:23', '2026-07-27 11:32:30'),
(3, 1, 'Perro', 'pau', 100, 100, 100, 100, 165, 1, 145, '2026-07-11 06:45:50', '2026-07-27 11:32:30'),
(4, 4, 'Gato', 'juansito', 100, 100, 100, 100, 100, 1, 45, '2026-07-11 07:39:23', '2026-07-27 11:32:30'),
(5, 5, 'Perro', 'pablo', 100, 100, 100, 100, 100, 1, 45, '2026-07-12 01:03:52', '2026-07-27 11:32:30'),
(6, 7, 'Gato', 'sandrita', 90, 100, 90, 100, 80, 1, 20, '2026-07-14 05:39:05', '2026-07-27 11:32:30'),
(7, 8, 'Gato', 'Pablo', 90, 97, 90, 100, 65, 1, 10, '2026-07-15 17:14:25', '2026-07-27 11:32:30'),
(8, 9, 'Perro', 'Chiringas', 75, 93, 90, 100, 65, 1, 10, '2026-07-15 17:22:36', '2026-07-27 11:32:30'),
(9, 10, '', 'Angel', 90, 95, 92, 100, 50, 1, 0, '2026-07-27 18:06:56', '2026-07-27 12:06:56'),
(10, 13, 'Tortuga', 'Angel', 80, 90, 84, 100, 50, 1, 0, '2026-07-27 18:14:59', '2026-07-27 12:14:59'),
(11, 14, 'Tortuga', 'angelito', 0, 0, 0, 0, 60, 1, 150, '2026-07-27 18:20:04', '2026-07-27 12:37:46'),
(12, 15, 'Perro', 'burrito', 80, 100, 90, 90, 45, 1, 30, '2026-07-27 18:40:17', '2026-07-27 12:42:07'),
(13, 16, 'Tortuga', 'jim', 39, 97, 0, 97, 25, 1, 110, '2026-08-01 17:59:20', '2026-08-01 12:00:04'),
(14, 17, 'Gato', 'miaw', 90, 95, 70, 95, 20, 1, 75, '2026-08-01 18:00:59', '2026-08-01 12:02:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tienda`
--

CREATE TABLE `tienda` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `precio` int(11) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `permanente` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tienda`
--

INSERT INTO `tienda` (`id_producto`, `nombre`, `precio`, `categoria`, `permanente`) VALUES
(1, 'Croquetas', 10, 'Comida', 0),
(2, 'Carne', 20, 'Comida', 0),
(3, 'Pescado', 25, 'Comida', 0),
(5, 'Pelota', 40, 'Juguete', 0),
(6, 'Hueso', 25, 'Juguete', 0),
(7, 'Ratón de Juguete', 30, 'Juguete', 0),
(9, 'Collar Rosa', 60, 'Accesorio', 1),
(10, 'Sombrero', 80, 'Accesorio', 1),
(11, 'Lentes', 180, 'Accesorio', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `edad` int(11) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `edad`, `correo`, `password`, `fecha_registro`) VALUES
(1, 'Emanuel', 18, 'emanuel@gmail.com', '12345', '2026-07-11 06:15:37'),
(2, 'Emanuel E', 10, 'emanuelito@gmail.com', '123456', '2026-07-11 06:30:41'),
(3, 'pau', 9, 'pau@gmail.com', '1234', '2026-07-11 06:34:43'),
(4, 'juan', 61, 'juan@gmail.com', '12345', '2026-07-11 07:38:53'),
(5, 'Pablo', 19, 'pablo@gmail.com', '12345', '2026-07-12 01:03:01'),
(6, 'Lupita', 19, 'lu@gmail.com', '1234', '2026-07-13 17:22:36'),
(7, 'Sandra', 40, 'sandra@gmail.com', '12345', '2026-07-14 05:38:47'),
(8, 'Paulita', 25, 'paulis@gmail.com', '12345', '2026-07-15 17:14:01'),
(9, 'Ruben', 23, 'Rubensito@gmail.com', '12345', '2026-07-15 17:21:56'),
(10, 'Pablito', 16, 'Pablito@gmail.com', '1234', '2026-07-27 18:06:33'),
(13, 'Lupissolis', 16, 'paulaaa@gmail.com', '1234', '2026-07-27 18:14:44'),
(14, 'ANGEL', 16, 'Angel1@gmail.com', '1234', '2026-07-27 18:19:51'),
(15, 'Angel', 19, 'maldonado@gmail.com', '1234', '2026-07-27 18:39:56'),
(16, 'Jimena', 3, 'jime@gmail.com', '1234', '2026-08-01 17:59:03'),
(17, 'gato', 5, 'gato@gmail.com', '1234', '2026-08-01 18:00:38');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `historial_acciones`
--
ALTER TABLE `historial_acciones`
  ADD PRIMARY KEY (`id_accion`),
  ADD KEY `fk_mascota_historial` (`id_mascota`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id_item`),
  ADD KEY `fk_mascota_inventario` (`id_mascota`);

--
-- Indices de la tabla `mascotas`
--
ALTER TABLE `mascotas`
  ADD PRIMARY KEY (`id_mascota`),
  ADD KEY `fk_usuario` (`id_usuario`);

--
-- Indices de la tabla `tienda`
--
ALTER TABLE `tienda`
  ADD PRIMARY KEY (`id_producto`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `historial_acciones`
--
ALTER TABLE `historial_acciones`
  MODIFY `id_accion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=295;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `mascotas`
--
ALTER TABLE `mascotas`
  MODIFY `id_mascota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `tienda`
--
ALTER TABLE `tienda`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `historial_acciones`
--
ALTER TABLE `historial_acciones`
  ADD CONSTRAINT `fk_mascota_historial` FOREIGN KEY (`id_mascota`) REFERENCES `mascotas` (`id_mascota`) ON DELETE CASCADE;

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `fk_mascota_inventario` FOREIGN KEY (`id_mascota`) REFERENCES `mascotas` (`id_mascota`) ON DELETE CASCADE;

--
-- Filtros para la tabla `mascotas`
--
ALTER TABLE `mascotas`
  ADD CONSTRAINT `fk_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
