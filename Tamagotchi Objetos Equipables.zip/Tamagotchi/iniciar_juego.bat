@echo off
title Tamagotchi App
python app.py
pause

