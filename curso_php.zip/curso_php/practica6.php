<html>
<head>
    <title>Práctica 6 - Número Aleatorio</title>
</head>
<body>
    <h1>Práctica 6: Número Aleatorio</h1>
    <?php
    $num = rand(1, 100);
    echo "El número generado aleatoriamente es: <b>$num</b><br>";
    
    if ($num <= 50) {
        echo "El número es menor o igual a 50.";
    } else {
        echo "El número es mayor a 50.";
    }
    ?>
</body>
</html>