<html>
<head>
    <title>Práctica 9 - Número en Letras</title>
</head>
<body>
    <h1>Práctica 9: Número Aleatorio del 1 al 5</h1>
    <?php
    $valor = rand(1, 5);
    echo "Número generado: $valor<br>";

    if ($valor == 1) {
        echo "uno";
    } elseif ($valor == 2) {
        echo "dos";
    } elseif ($valor == 3) {
        echo "tres";
    } elseif ($valor == 4) {
        echo "cuatro";
    } else {
        echo "cinco";
    }
    ?>
</body>
</html>