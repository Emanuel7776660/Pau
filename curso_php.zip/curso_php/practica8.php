<html>
<head>
    <title>Práctica 8 - Sustitución de Variables</title>
</head>
<body>
    <h1>Práctica 8: Sustitución en Strings</h1>
    <?php
    $precio1 = 90;
    $precio2 = 450;
    $precio3 = 1200;

    echo "La computadora 1 tiene un precio de $$precio1<br>";
    echo "La computadora 2 tiene un precio de $$precio2<br>";
    echo "La computadora 3 tiene un precio de $$precio3<br>";
    ?>
</body>
</html>