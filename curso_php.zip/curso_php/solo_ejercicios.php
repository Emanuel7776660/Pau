<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ejercicios del Libro (17 al 23)</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f9f9fb; color: #333; }
        .seccion { background: #fff; padding: 20px; margin-bottom: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px; }
        table { border-collapse: collapse; width: 60%; margin-top: 10px; }
        table, th, td { border: 1px solid #ccc; padding: 6px; text-align: center; font-size: 14px; }
    </style>
</head>
<body>

    <h1>Ejercicios Resueltos (Ejercicios 17 al 23)</h1>
   

    <!-- EJERCICIO 17 - SWITCH -->
    <div class="seccion">
        <h2>Ejercicio 17 - 16_switch.php</h2>
        <?php
        $posicion = "arriba";
        echo "La variable posicion es <b>$posicion</b><br><br>";
        
        switch($posicion){
            case "arriba":
                echo "La variable contiene el valor de arriba";
                break;
            case "abajo":
                echo "La variable contiene el valor de abajo";
                break;
            default:
                echo "La variable contiene otro valor distinto arriba y abajo";
        }
        ?>
    </div>

    <!-- EJERCICIO 18 - TABLA 1 -->
    <div class="seccion">
        <h2>Ejercicio 18 - 17_Tabla1.php</h2>
        <?php
        function muestra_e18($valor) {
            if ($valor < 0.5) {
                $color = "red";
            } else {
                $color = "blue";
            }
            echo "<td><font color='$color'>$valor</font></td>\n";
        }
        ?>
        <table border="1">
        <?php
        for ($x = 0; $x <= 2; $x += 0.1) { 
            echo "<tr>";
            muestra_e18($x);
            muestra_e18(sin($x));
            muestra_e18(cos($x));
            echo "</tr>";
        }
        ?>
        </table>
    </div>

    <!-- EJERCICIO 19 - TABLA 2 -->
    <div class="seccion">
        <h2>Ejercicio 19 - 18_tabla2.php</h2>
        <?php
        function muestra_e19($valor, $renglon) {
            if ($renglon % 2) {
                $fondo = "#eeeeee";
            } else {
                $fondo = "#dddddd";
            }

            if ($valor < 0.5) {
                $color = "red";
            } else {
                $color = "blue";
            }
            echo "<td bgcolor='$fondo'><font color='$color'>$valor</font></td>\n";
        }
        ?>
        <table border="1">
        <?php
        $nrenglon = 0;
        for ($x = 0; $x <= 2; $x += 0.1) {
            echo "<tr>";
            muestra_e19($x, $nrenglon);
            muestra_e19(sin($x), $nrenglon);
            muestra_e19(cos($x), $nrenglon);
            echo "</tr>";
            $nrenglon++;
        }
        ?>
        </table>
    </div>

    <!-- EJERCICIO 20 - TABLA 3 -->
    <div class="seccion">
        <h2>Ejercicio 20 - 19_tabla3.php (Variables Globales)</h2>
        <?php
        function muestra_e20($valor) {
            global $nrenglon_g;
            if ($nrenglon_g % 2) {
                $fondo = "#ffff00";
            } else {
                $fondo = "#ffffff";
            }

            if ($valor < 0.5) {
                $color = "red";
            } else {
                $color = "blue";
            }
            echo "<td bgcolor='$fondo'><font color='$color'>$valor</font></td>\n";
        }
        ?>
        <table border="1">
        <?php
        global $nrenglon_g;
        $nrenglon_g = 0;
        for ($x = 0; $x <= 2; $x += 0.1) {
            echo "<tr>";
            muestra_e20($x);
            muestra_e20(sin($x));
            muestra_e20(cos($x));
            echo "</tr>";
            $nrenglon_g++;
        }
        ?>
        </table>
    </div>

    <!-- EJERCICIOS 21 y 22 - WHILE Y FORMULARIO -->
    <div class="seccion">
        <h2>Ejercicios 21 y 22 - 20_while / 20_whileB.php</h2>
        <form method="post">
            ¿Cuántas veces? <input type="text" name="number" value="4">
            <input type="submit" value="Enviar">
        </form>
        <br>
        <?php
        if (isset($_POST['number']) && $_POST['number'] != "") {
            $number = $_POST['number'];
            $counter = 1;
            while ($counter <= $number) {
                echo "<b>$counter</b>.- Los bucles son fáciles!<br>\n";
                $counter++;
            }
            echo "Se acabó.<br>";
        }
        ?>
    </div>

    <!-- EJERCICIO 23 - LIBRERÍA Y FUNCIONES -->
    <div class="seccion">
        <h2>Ejercicio 23 - 21_libreria.phtml y páginas</h2>
        <?php
        // Simulación de funciones de librería
        function CabeceraPagina() {
            echo '<FONT SIZE="+1">Esta cabecera estará en todas sus páginas.</FONT><BR><hr>';
        }

        function PiePagina() {
            echo '<hr><FONT SIZE="-1">Este es el pie de página.</FONT><BR>Autor: Joaquin Gracia';
        }

        CabeceraPagina();
        echo "<br><b>Página de demostración:</b><br>Contenido principal de la página de ejemplo.<br><br>";
        PiePagina();
        ?>
    </div>

</body>
</html>