<html>
<head>
    <title>Práctica 10 - Tabla del 2</title>
</head>
<body>
    <h1>Tabla de multiplicar del 2</h1>

    <h3>Usando FOR:</h3>
    <?php
    for ($f = 2; $f <= 20; $f = $f + 2) {
        echo "$f <br>";
    }
    ?>

    <h3>Usando WHILE:</h3>
    <?php
    $f = 2;
    while ($f <= 20) {
        echo "$f <br>";
        $f = $f + 2;
    }
    ?>

    <h3>Usando DO / WHILE:</h3>
    <?php
    $f = 2;
    do {
        echo "$f <br>";
        $f = $f + 2;
    } while ($f <= 20);
    ?>
</body>
</html>