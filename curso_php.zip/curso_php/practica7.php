<html>
<head>
    <title>Práctica 7 - Tipos de Datos</title>
</head>
<body>
    <h1>Práctica 7: Tipos de Variables</h1>
    <?php
    $entero = 25;                  // Integer
    $decimal = 99.99;              // Double
    $texto = "Hola Programadores"; // String
    $activo = true;                // Boolean (se imprime como 1 si es true)

    echo "Entero: $entero<br>";
    echo "Double: $decimal<br>";
    echo "String: $texto<br>";
    echo "Boolean: " . ($activo ? 'Verdadero' : 'Falso') . "<br>";
    ?>
</body>
</html>